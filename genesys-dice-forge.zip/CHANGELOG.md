# 0.7.3 - Top Layer + Automatic Genesys Bridge

- Makes the 3D dice canvas an always-on-top, click-through viewport layer so Foundry Actor sheets, dialogs and other application windows no longer cover a roll.
- Uses a hardened top-level z-index both in CSS and inline renderer setup for Foundry VTT 13.351 / v14.
- Adds an automatic Genesys system bridge that listens for common resolved-roll hooks and inspects Genesys chat messages for authoritative per-die type + face data.
- Preserves the preferred direct `presentResolvedSystemRoll()` integration for exact pre-chat timing; automatic bridging is a compatibility fallback and never re-rolls an authoritative result.
- Adds a client setting `Automatic Genesys System Bridge` (enabled by default).
- Standalone Dice Forge chat cards are marked so they cannot trigger duplicate 3D rolls.

# Changelog

## 0.7.1
- Reworked deterministic settling so the authoritative result face finishes physically upward with a consistent player-readable face orientation instead of a random final yaw.
- Replaced the previous visible last-moment twist with a small decaying horizontal micro-rock and exact face-up completion.
- Increased the stationary result hold to improve top-face readability before fade-out.
- Added a standalone Genesys Dice Forge roll simulator with six narrative-die counters and exact pool-size/type presentation.
- Added random face generation using the die definitions already used by the renderer.
- Added standalone narrative resolution for Success/Failure, Advantage/Threat, Triumph and Despair, including Triumph=Success and Despair=Failure semantics without cancelling the special symbols.
- Added optional simulator result posting to Foundry chat.
- Added public `createSimulatedRoll()` and `rollPool()` APIs while preserving `animateRoll()` for authoritative custom-system payloads.
- Added a client setting to show/hide the standalone Dice Forge Roller.
- Premium v0.7.0 dice artwork, v0.6.2 table physics and v0.3.3 GOLD adaptive audio remain otherwise unchanged.

## 0.7.0
- Rebuilt the fantasy face-artwork pass to match the approved premium physical dice target: polished enamel/stone body, subtle wear, clean forged metal trim, recessed socket and restrained bevel highlights.
- Removed the previous heavy filigree, medallion, corner ornament and stud treatment.
- Switched runtime glyph rendering to the six locked user-approved silhouette masks rather than the older pre-colored artwork files.
- Added explicit die-specific symbol contrast: black on Boost/Ability/Proficiency/Challenge, light on Setback/Difficulty.
- Preserved true blank faces and exact audited Genesys face composition for all six narrative dice.
- Refined double/mixed result placement so two symbols remain two discrete glyphs, with compact layouts adapted for triangular d8 faces versus d6/d12 faces.
- Increased face-atlas tile resolution from 384 px to 512 px.
- Added polished clear-coat/specular response to the WebGL die shader and reduced artificial target-face tinting.
- Kept Triumph/Despair live signature glow as a separate emissive accent so black Challenge glyphs remain black.
- Added the approved premium concept render as a non-runtime design reference.
- Kept v0.6.2 overhand-drop/right-rail-rebound physics and v0.3.3 GOLD adaptive audio unchanged.

## 0.6.2
- Reworked the rigid-body release into a faster **upper-left overhand table drop** based on live Foundry QA feedback.
- Dice now enter high from the left/back of the virtual tabletop, already falling under gravity while traveling diagonally right and toward the player's viewpoint.
- Increased drop gravity and initial angular velocity so the first table impact reads as a thrown handful rather than objects sliding in from off-screen.
- Added a stronger rightward release vector and reduced pre-rail rolling resistance so dice naturally reach the invisible right tabletop rail.
- Strengthened right-rail restitution and spin transfer so the impact visibly rebounds the dice back into the play area.
- Increased rolling resistance after the first right-rail rebound, producing a shorter return path and a faster overall animation.
- Tightened the handful release stagger and shortened simulation/settle/hold timing for a more immediate roll presentation.
- Added a guard that gives the intended right-edge rebound time to occur before low-energy sleep/settle begins, while retaining a hard safety timeout.
- Final upward faces remain the exact authoritative Genesys `faceIndex` values; physics remains presentation-only.
- Signature glyph artwork and the v0.3.3 GOLD adaptive audio are unchanged.

## 0.6.1
- Hotfix for the v0.6.0 audio-only regression.
- Restored the WebGL die-mesh and shadow-mesh constructors that were accidentally dropped during the rigid-body physics refactor.
- The failed renderer initialization previously triggered the safe null-renderer fallback, which is why adaptive dice audio still played while no dice were visible.
- No changes to rigid-body physics tuning, signature artwork, authoritative face settling, die scale, or GOLD adaptive audio.
- Added a renderer-source integrity QA check for the required mesh constructors.

## 0.6.0
- Replaced v0.5.0 scripted table travel/bounce curves with a lightweight deterministic rigid-body simulation.
- Added per-die linear velocity, angular velocity, mass, collision radius, gravity and shape-specific restitution/friction.
- Added real floor-plane contacts, rolling coupling and energy decay so the Foundry desktop behaves as a physical table.
- Added mass-weighted 3D die-to-die collision impulses and angular spin transfer.
- Added invisible tabletop bounds on the right and depth axes so dice can rebound rather than leave the visible desktop.
- Removed predetermined result layout slots; final x/z positions now emerge from the simulation.
- Dice launch from the left as an independently randomized handful with small stagger, unique velocity and unique spin.
- Added sleep detection plus a safety timeout before the deterministic result settle phase.
- Deterministic settle remains presentation-only and ends on the exact authoritative Genesys `faceIndex`.
- Increased final result hold to ~1.85 seconds for readability.
- Preserved signature fantasy artwork and GOLD adaptive audio unchanged.
- Continues to use an isolated WebGL overlay for Foundry VTT 13.351 / v14 compatibility.

## 0.5.0
- Reworked roll presentation so the Foundry viewport behaves as a virtual tabletop: dice enter from the left and roll toward a right-hand result zone.
- Added friction-like horizontal deceleration, low release arcs, diminishing table impacts and a final contact wobble.
- Added deterministic die-to-die tabletop contact separation for more convincing multi-die motion.
- Removed the former 18-die visual truncation so the presentation matches the full authoritative Genesys pool count and die types.
- Added hybrid settle-assist: free visual rolling converges smoothly on the exact authoritative `faceIndex` during the final quarter of motion.
- Result positions and motion remain seeded from `rollId`; rules resolution is still entirely owned by the Genesys system.
- Preserved v0.4.0 signature glyph artwork and the v0.3.3 GOLD adaptive audio unchanged.
- Continues to use a separate WebGL overlay and does not mount into Foundry canvas/PIXI internals.

## 0.4.0
- Replaced the simplified procedural narrative glyphs with the six user-approved silhouettes from the supplied reference image.
- Added clean 512 px transparent signature artwork assets for Success, Advantage, Triumph, Failure, Threat and Despair, preserving the approved silhouettes while adding dark recessed sockets, aged-bronze bezels and warm ivory/gold inlays.
- Increased generated face-atlas resolution from 256 px to 384 px per tile for stronger readability on compact dice.
- Strengthened the fantasy face artwork with deeper jewel/stone glazing, forged double frames, medallion recesses, hammered flecks, larger filigree and more physical highlight/shadow treatment.
- Updated Triumph/Despair live glow geometry to match the approved sun-wheel and circled-X visual family.
- Kept the compact v0.3.1+ die scale unchanged.
- Kept the v0.3.3 adaptive multi-sample dice audio unchanged as the current GOLD sound baseline.
- No changes to exact audited face distributions, deterministic authoritative `faceIndex` playback, or Foundry-canvas isolation.

## 0.3.3
- Added the first adaptive **Genesys Dice Audio** layer using the user-supplied dice recordings as source material.
- Cut, normalized and packaged seven short roll samples into light, medium and heavy banks instead of replaying the raw source files directly.
- Roll audio now scales with pool size: 1-2 dice stay tight, 3-5 dice layer a second clatter, 6-9 dice use a fuller multi-die bed, and 10+ dice stack several staggered samples for a convincing handful-of-dice feel.
- Added subtle randomized playback-rate variation and micro-delays so repeated rolls do not sound identical.
- Added local **Enable Dice Sounds** and **Dice Sound Volume** client settings.
- QA TEST DICE now previews the same six-die visual roll with the adaptive audio layer.
- Audio remains presentation-only and does not affect Genesys result authority, deterministic face playback, or Foundry canvas state.

## 0.3.2
- Added a true face-artwork rendering pass inspired directly by the approved Fantasy Dice concept artwork.
- Each die face now receives a generated high-resolution artwork atlas with antique bronze inset framing, filigree, enamel/stone veining, rivet details and layered engraved narrative glyphs.
- Replaced the previous simple always-on line-symbol presentation with artwork-textured face symbols; live vector glow remains reserved for Triumph and Despair.
- Added per-face UV coordinates to procedural d6/d8/d12 geometry and native WebGL artwork-atlas sampling.
- Preserves the compact v0.3.1 QA scale (~41–42% of v0.3.0), which is slightly smaller than half-size.
- Theme switching now rebuilds artwork atlases safely and renderer teardown releases WebGL textures.
- No changes to Genesys result authority or audited face distributions.

## 0.3.1
- Reduced all rendered dice to roughly 41–42% of the v0.3.0 QA scale after live Foundry video review.
- Preserved the intended relative silhouette hierarchy: d12 slightly larger than d8, d8 slightly larger than d6.
- Tightened multi-die landing spacing so the smaller dice remain a coherent roll cluster instead of spreading across the canvas.
- Reduced throw spread, drop height and bounce amplitude to match the new compact physical scale.
- No changes to authoritative face results, symbols, materials or Genesys rules integration.

## 0.3.0
- Added exact audited face distributions for all six narrative dice.
- Added custom non-proprietary vector glyphs for Success, Failure, Advantage, Threat, Triumph and Despair.
- Added symbol geometry projected onto every die face.
- Added stone/enamel grain, roughness and metallic material controls.
- Reduced die scale and increased multi-die spacing after live Foundry QA.
- Added presentation-lite bounce and more grounded settling.
- Added Triumph/Despair symbol glow accent.
- Preserved deterministic authoritative face playback and Foundry-canvas isolation.

## 0.2.0
- Added native dependency-free WebGL renderer.
- Added procedural d6, d8 and d12 convex-polyhedron geometry.
- Added deterministic face-up orientation using authoritative `faceIndex`.
- Added seeded throw/spin presentation without gameplay physics.
- Added perspective camera, directional lighting, specular/rim highlights and soft ground shadows.
- Added Fantasy theme material rendering and bronze edge pass.
- Added responsive resize/high-DPI handling.
- Added safe fallback renderer when WebGL initialization fails.
- Added QA / Debug Mode with local **TEST DICE** button.
- Strengthened Foundry V13.351 / V14 compatibility checks and isolated asset routing.

## 0.1.0
- Initial Genesys Dice Forge module skeleton.
- Added V13.351/V14 compatibility adapter boundary.
- Added deterministic six-die roll payload contract.
- Added Fantasy theme design tokens.
- Added system bridge API and implementation roadmap.
