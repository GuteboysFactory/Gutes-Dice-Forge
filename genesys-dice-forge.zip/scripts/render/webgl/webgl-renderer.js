// v0.7.17 NATURAL_LANDING_AUTHORITATIVE_FACE_REMAP
import { getViewportHost } from "../../compat/foundry.js";
import { getDieDefinition, getFaceSymbols } from "../../core/dice-types.js";
import { getShapeGeometry } from "./geometry.js";
import { createArrayBuffer, createProgram, bindAttribute, uniformLocation } from "./gl-utils.js";
import { createDieArtworkTexture } from "./artwork-texture.js";
import { buildDieSymbolLines } from "./symbol-geometry.js";
import {
  clamp,
  hashString,
  hexToRgb01,
  mat4FromRotationTranslationScale,
  mat4LookAt,
  mat4Multiply,
  mat4Perspective,
  mulberry32,
  quatFromAxisAngle,
  quatFromTo,
  quatMultiply,
  quatRotateVec3,
  quatSlerp,
  smoothstep
} from "./math.js";
import { loadTheme } from "./theme-loader.js";
import {
  DIE_VERTEX_SHADER,
  DIE_FRAGMENT_SHADER,
  EDGE_VERTEX_SHADER,
  EDGE_FRAGMENT_SHADER,
  SHADOW_VERTEX_SHADER,
  SHADOW_FRAGMENT_SHADER,
  SYMBOL_VERTEX_SHADER,
  SYMBOL_FRAGMENT_SHADER
} from "./shaders.js";

const UP = [0, 1, 0];
const GROUND_Y = -1.55;
const CAMERA_POSITION = [0, 7.35, 12.4];
const CAMERA_TARGET = [0, 0.0, 0];

// The Foundry viewport is treated as a real virtual tabletop plane. Dice are
// launched from the left with independent linear/angular velocity, collide
// with the table and each other, lose energy through friction, then receive a
// short deterministic settle-assist so the authoritative Genesys face ends up.
const TABLE = Object.freeze({
  // Dice now enter high from the upper-left/back of the virtual table, drop
  // toward the player's viewpoint, strike the desktop, then carry their
  // momentum into the right rail before rebounding back into the play area.
  spawnX: -7.20,
  wallLeftX: -8.15,
  wallRightX: 6.05,
  minZ: -2.45,
  maxZ: 2.25
});

const PHYSICS = Object.freeze({
  gravity: -14.8,
  fixedStep: 1 / 120,
  maxFrameDelta: 1 / 20,
  minSimulationMs: 1250,
  maxSimulationMs: 3050,
  settleMs: 180,
  holdMs: 2250,
  wallRestitution: 0.48,
  diceRestitution: 0.38
});

// Three motion profiles share the same upper-left release. Variation begins only
// after the first tabletop impact so Dice Forge keeps a recognizable signature
// while avoiding the exact same physical story on every roll. Profiles never
// influence the authoritative faceIndex; they only change post-impact motion.
const ROLL_PROFILES = Object.freeze([
  Object.freeze({
    id: "rail-rebound",
    weight: 0.40,
    bounceMultiplier: 1.00,
    firstImpactLateralKick: 0.10,
    firstImpactForwardMultiplier: 1.00,
    preRailDampingOffset: 0.09,
    postRailDampingOffset: -0.13,
    railDrive: 0.62,
    requireRailForSleep: true,
    guideAfterMs: 1050,
    maxSimulationMs: 3050
  }),
  Object.freeze({
    id: "scatter-roll",
    weight: 0.35,
    bounceMultiplier: 0.96,
    firstImpactLateralKick: 1.15,
    firstImpactForwardMultiplier: 0.91,
    preRailDampingOffset: 0.03,
    postRailDampingOffset: -0.10,
    railDrive: 0.18,
    requireRailForSleep: false,
    guideAfterMs: 1450,
    maxSimulationMs: 2920
  }),
  Object.freeze({
    id: "deep-bounce",
    weight: 0.25,
    bounceMultiplier: 1.30,
    firstImpactLateralKick: 0.34,
    firstImpactForwardMultiplier: 0.97,
    preRailDampingOffset: 0.07,
    postRailDampingOffset: -0.08,
    railDrive: 0.32,
    requireRailForSleep: false,
    guideAfterMs: 1500,
    maxSimulationMs: 3260
  })
]);

function chooseRollProfile(random) {
  const roll = random();
  let cursor = 0;
  for (const profile of ROLL_PROFILES) {
    cursor += profile.weight;
    if (roll <= cursor) return profile;
  }
  return ROLL_PROFILES[0];
}

// v0.7.9 Guided Settle: keep the beginning of every throw fully physical, then
// bias only the late rolling angular velocity toward the already-authoritative
// face. The final deterministic settle should therefore be a micro-correction,
// not a visible last-second twist.
const GUIDED_SETTLE = Object.freeze({
  freePhysicsMs: 700,
  guideLeadMs: 430,
  maxHorizontalSpeed: 3.40,
  maxVerticalSpeed: 0.52,
  sleepFaceAngle: 0.025,
  graceMs: 1200,
  hardAssistStartMs: 300,
  hardAssistRate: 6.8,
  hardAssistMaxStep: 0.075,
  settleFaceAngle: 0.040,
  terminalAssistMs: 900,
  hardStopMs: 5600
});

// GPU mesh helpers are deliberately kept independent from the rigid-body
// state. v0.6.0 accidentally dropped these two constructors during the
// physics refactor, which made WebGL initialization fall back to the null
// renderer while the independent audio engine continued to play.
function createMesh(gl, geometry) {
  return {
    geometry,
    position: createArrayBuffer(gl, geometry.positions),
    normal: createArrayBuffer(gl, geometry.normals),
    faceIndex: createArrayBuffer(gl, geometry.faceIndices),
    faceUv: createArrayBuffer(gl, geometry.faceUvs),
    edge: createArrayBuffer(gl, geometry.edgePositions),
    triangleVertexCount: geometry.positions.length / 3,
    edgeVertexCount: geometry.edgePositions.length / 3
  };
}

function createShadowMesh(gl) {
  const positions = new Float32Array([
    -1, 0, -1, 1, 0, -1, 1, 0, 1,
    -1, 0, -1, 1, 0, 1, -1, 0, 1
  ]);
  const uv = new Float32Array([
    0, 0, 1, 0, 1, 1,
    0, 0, 1, 1, 0, 1
  ]);
  return {
    position: createArrayBuffer(gl, positions),
    uv: createArrayBuffer(gl, uv),
    vertexCount: 6
  };
}

function shapePhysics(shape) {
  switch (shape) {
    case "d12":
      return { mass: 1.22, floorRestitution: 0.30, linearDamping: 0.61, angularDamping: 0.53 };
    case "d8":
      return { mass: 1.09, floorRestitution: 0.28, linearDamping: 0.54, angularDamping: 0.47 };
    default:
      return { mass: 1.00, floorRestitution: 0.25, linearDamping: 0.47, angularDamping: 0.42 };
  }
}

function geometryRadius(geometry, scale) {
  let radius = 0;
  for (const vertex of geometry.vertices) {
    radius = Math.max(radius, Math.hypot(vertex[0], vertex[1], vertex[2]));
  }
  return radius * scale * 0.92;
}

function bottomOffsetY(geometry, rotation, scale) {
  let minY = Infinity;
  for (const vertex of geometry.vertices) {
    const transformed = quatRotateVec3(rotation, vertex);
    minY = Math.min(minY, transformed[1] * scale);
  }
  return minY;
}

function contactCenterY(entry, rotation = entry.rotation) {
  return GROUND_Y - bottomOffsetY(entry.mesh.geometry, rotation, entry.scale);
}

function integrateRotation(rotation, angularVelocity, dt) {
  const speed = Math.hypot(angularVelocity[0], angularVelocity[1], angularVelocity[2]);
  if (speed < 0.0001) return rotation;
  const axis = [angularVelocity[0] / speed, angularVelocity[1] / speed, angularVelocity[2] / speed];
  return quatMultiply(quatFromAxisAngle(axis, speed * dt), rotation);
}

function applyTableBounds(entry) {
  const r = entry.collisionRadius;
  if (entry.position[0] + r > TABLE.wallRightX) {
    entry.position[0] = TABLE.wallRightX - r;
    if (entry.velocity[0] > 0) {
      entry.velocity[0] *= -PHYSICS.wallRestitution;
      entry.rightWallHits = (entry.rightWallHits ?? 0) + 1;
      // A rail strike should read clearly as a physical rebound rather than a
      // hard stop. Preserve a little depth motion and transfer some energy
      // into spin, as a real polyhedral die would when clipping an edge.
      entry.velocity[2] *= 0.94;
      entry.angularVelocity[1] += entry.velocity[2] * 0.18;
      entry.angularVelocity[2] -= entry.velocity[0] * 0.10;
    }
  }
  if (entry.position[0] - r < TABLE.wallLeftX) {
    entry.position[0] = TABLE.wallLeftX + r;
    if (entry.velocity[0] < 0) entry.velocity[0] *= -0.26;
  }
  if (entry.position[2] + r > TABLE.maxZ) {
    entry.position[2] = TABLE.maxZ - r;
    if (entry.velocity[2] > 0) entry.velocity[2] *= -PHYSICS.wallRestitution;
    entry.angularVelocity[0] -= entry.velocity[0] * 0.06;
  }
  if (entry.position[2] - r < TABLE.minZ) {
    entry.position[2] = TABLE.minZ + r;
    if (entry.velocity[2] < 0) entry.velocity[2] *= -PHYSICS.wallRestitution;
    entry.angularVelocity[0] += entry.velocity[0] * 0.06;
  }
}

function stepDie(entry, dt, simulationElapsedMs) {
  if (simulationElapsedMs < entry.delay) {
    entry.opacity = 0;
    return;
  }

  entry.opacity = clamp((simulationElapsedMs - entry.delay) / 150);

  // Airborne rigid-body integration.
  entry.velocity[1] += PHYSICS.gravity * dt;
  const airDrag = Math.pow(0.9985, dt * 60);
  entry.velocity[0] *= airDrag;
  entry.velocity[2] *= airDrag;

  entry.position[0] += entry.velocity[0] * dt;
  entry.position[1] += entry.velocity[1] * dt;
  entry.position[2] += entry.velocity[2] * dt;
  entry.rotation = integrateRotation(entry.rotation, entry.angularVelocity, dt);

  const floorY = contactCenterY(entry);
  const onOrBelowFloor = entry.position[1] <= floorY;
  if (onOrBelowFloor) {
    const impactSpeed = Math.max(0, -entry.velocity[1]);
    entry.position[1] = floorY;

    if (impactSpeed > 0.42) {
      entry.velocity[1] = impactSpeed * entry.physics.floorRestitution * entry.rollProfile.bounceMultiplier;
      entry.angularVelocity[0] += entry.impactTwist[0] * impactSpeed * 0.24;
      entry.angularVelocity[1] += entry.impactTwist[1] * impactSpeed * 0.16;
      entry.angularVelocity[2] += entry.impactTwist[2] * impactSpeed * 0.24;
    } else {
      entry.velocity[1] = 0;
    }

    if (!entry.firstFloorImpact) {
      entry.firstFloorImpact = true;
      // All profiles arrive with the same release. This is the first point at
      // which their motion diverges: Rail Rebound stays nearly straight,
      // Scatter fans across the tabletop, and Deep Bounce keeps more vertical
      // energy. Each die still gets a small independent variation.
      const lateral = entry.rollProfile.firstImpactLateralKick
        * entry.profileLateralSign
        * (0.72 + entry.profileLateralAmount * 0.56);
      entry.velocity[2] += lateral;
      entry.velocity[0] *= entry.rollProfile.firstImpactForwardMultiplier;
      if (entry.rollProfile.id === "scatter-roll") {
        entry.angularVelocity[1] += entry.profileLateralSign * (0.55 + entry.profileLateralAmount * 0.75);
      } else if (entry.rollProfile.id === "deep-bounce") {
        entry.angularVelocity[0] += entry.impactTwist[0] * 0.9;
        entry.angularVelocity[2] += entry.impactTwist[2] * 0.9;
      }
    }

    // Coulomb-ish tabletop friction and rolling coupling. The different
    // polyhedra retain different amounts of energy: d12 rolls longest, d6
    // sheds energy fastest.
    // Keep more of the release energy until the die has visibly reached the
    // right rail. After the first rail rebound, increase rolling resistance so
    // the return trip is shorter and the whole animation stays snappy.
    const dampingBase = entry.rightWallHits > 0
      ? Math.max(0.30, entry.physics.linearDamping + entry.rollProfile.postRailDampingOffset)
      : Math.min(0.78, entry.physics.linearDamping + entry.rollProfile.preRailDampingOffset);
    const linear = Math.pow(dampingBase, dt);
    entry.velocity[0] *= linear;
    entry.velocity[2] *= linear;

    const horizontalSpeed = Math.hypot(entry.velocity[0], entry.velocity[2]);
    if (horizontalSpeed > 0.08) {
      const radius = Math.max(0.1, entry.collisionRadius);
      const desiredRoll = [
        entry.velocity[2] / radius * 0.72,
        entry.angularVelocity[1] * 0.92,
        -entry.velocity[0] / radius * 0.72
      ];
      const coupling = Math.min(1, dt * 8.5);
      entry.angularVelocity[0] += (desiredRoll[0] - entry.angularVelocity[0]) * coupling;
      entry.angularVelocity[1] += (desiredRoll[1] - entry.angularVelocity[1]) * coupling;
      entry.angularVelocity[2] += (desiredRoll[2] - entry.angularVelocity[2]) * coupling;
    }

    const angular = Math.pow(entry.physics.angularDamping, dt);
    entry.angularVelocity[0] *= angular;
    entry.angularVelocity[1] *= angular;
    entry.angularVelocity[2] *= angular;

    // v0.7.17: natural landing; no target-face torque or quaternion assist.

    // Preserve the physical intent of an overhand release toward the right
    // rail without steering toward a final landing slot. This only tops up a
    // nearly-spent die before its first rail contact; after that, no drive is
    // applied and the rebound/friction determine its resting place.
    if ((entry.rightWallHits ?? 0) === 0
      && entry.position[0] < TABLE.wallRightX - entry.collisionRadius - 0.45
      && entry.velocity[0] < 2.7) {
      entry.velocity[0] += entry.rollProfile.railDrive * dt;
    }

    if (horizontalSpeed < 0.055) {
      entry.velocity[0] = 0;
      entry.velocity[2] = 0;
    }
  }

  applyTableBounds(entry);
}

function resolveRigidDiceContacts(states, simulationElapsedMs) {
  for (let i = 0; i < states.length; i += 1) {
    const a = states[i];
    if (simulationElapsedMs < a.delay) continue;
    for (let j = i + 1; j < states.length; j += 1) {
      const b = states[j];
      if (simulationElapsedMs < b.delay) continue;

      let dx = b.position[0] - a.position[0];
      let dy = b.position[1] - a.position[1];
      let dz = b.position[2] - a.position[2];
      let distance = Math.hypot(dx, dy, dz);
      const minimum = a.collisionRadius + b.collisionRadius;
      if (distance >= minimum) continue;

      if (distance < 0.0001) {
        dx = 0.001;
        dy = 0.0005;
        dz = ((i + j) % 2 ? 1 : -1) * 0.001;
        distance = Math.hypot(dx, dy, dz);
      }

      const nx = dx / distance;
      const ny = dy / distance;
      const nz = dz / distance;
      const overlap = minimum - distance;
      const invMassA = 1 / a.physics.mass;
      const invMassB = 1 / b.physics.mass;
      const invMassSum = invMassA + invMassB;

      // Mass-weighted positional correction keeps contacts stable without
      // placing the dice into a predetermined layout.
      const correction = Math.max(0, overlap - 0.002) / invMassSum * 0.76;
      a.position[0] -= nx * correction * invMassA;
      a.position[1] -= ny * correction * invMassA;
      a.position[2] -= nz * correction * invMassA;
      b.position[0] += nx * correction * invMassB;
      b.position[1] += ny * correction * invMassB;
      b.position[2] += nz * correction * invMassB;

      const rvx = b.velocity[0] - a.velocity[0];
      const rvy = b.velocity[1] - a.velocity[1];
      const rvz = b.velocity[2] - a.velocity[2];
      const relativeNormalSpeed = rvx * nx + rvy * ny + rvz * nz;
      if (relativeNormalSpeed < 0) {
        const impulse = -(1 + PHYSICS.diceRestitution) * relativeNormalSpeed / invMassSum;
        const ix = nx * impulse;
        const iy = ny * impulse;
        const iz = nz * impulse;
        a.velocity[0] -= ix * invMassA;
        a.velocity[1] -= iy * invMassA;
        a.velocity[2] -= iz * invMassA;
        b.velocity[0] += ix * invMassB;
        b.velocity[1] += iy * invMassB;
        b.velocity[2] += iz * invMassB;

        const spinKick = impulse * 0.34;
        a.angularVelocity[0] -= nz * spinKick * invMassA;
        a.angularVelocity[1] += (nx - nz) * spinKick * 0.32 * invMassA;
        a.angularVelocity[2] += nx * spinKick * invMassA;
        b.angularVelocity[0] += nz * spinKick * invMassB;
        b.angularVelocity[1] -= (nx - nz) * spinKick * 0.32 * invMassB;
        b.angularVelocity[2] -= nx * spinKick * invMassB;
      }
    }
  }
}

function resultFaceError(entry) {
  const localNormal = entry.mesh.geometry.faceNormals[entry.die.faceIndex];
  const worldNormal = quatRotateVec3(entry.rotation, localNormal);
  const cosAngle = clamp(worldNormal[1], -1, 1);
  const crossX = worldNormal[2];
  const crossZ = -worldNormal[0];
  const crossLength = Math.hypot(crossX, crossZ);
  const angle = Math.atan2(crossLength, cosAngle);

  if (crossLength >= 0.0001) {
    return { angle, axisX: crossX / crossLength, axisZ: crossZ / crossLength };
  }

  // Exactly face-up or face-down has no unique horizontal correction axis.
  // Reuse the current physical roll axis so the guidance remains a continuation
  // of the motion the player is already seeing.
  const fallbackLength = Math.max(0.0001, Math.hypot(entry.angularVelocity[0], entry.angularVelocity[2]));
  return {
    angle,
    axisX: entry.angularVelocity[0] / fallbackLength || 1,
    axisZ: entry.angularVelocity[2] / fallbackLength || 0
  };
}

function topPhysicalFaceIndex(entry) {
  let bestIndex = 0;
  let bestY = -Infinity;
  const normals = entry.mesh.geometry.faceNormals;
  for (let i = 0; i < normals.length; i += 1) {
    const worldNormal = quatRotateVec3(entry.rotation, normals[i]);
    if (worldNormal[1] > bestY) {
      bestY = worldNormal[1];
      bestIndex = i;
    }
  }
  return bestIndex;
}

function dieIsNearlySleeping(entry, simulationElapsedMs) {
  if (simulationElapsedMs < entry.delay + 650) return false;
  // Give the intended right-edge rebound time to happen before considering a
  // die asleep. A safety timeout still prevents a blocked die from stalling
  // the presentation indefinitely.
  if (entry.rollProfile.requireRailForSleep
    && (entry.rightWallHits ?? 0) === 0
    && simulationElapsedMs < entry.delay + 2150) return false;
  const floorY = contactCenterY(entry);
  const horizontal = Math.hypot(entry.velocity[0], entry.velocity[2]);
  const vertical = Math.abs(entry.velocity[1]);
  const angular = Math.hypot(entry.angularVelocity[0], entry.angularVelocity[1], entry.angularVelocity[2]);
  return Math.abs(entry.position[1] - floorY) < 0.035
    && horizontal < 0.34
    && vertical < 0.18
    && angular < 1.35;
}

function buildFaceUpTargetRotation(geometry, faceIndex, currentRotation) {
  // The result is authoritative, but the presentation correction should be
  // almost invisible. Align only the selected face normal with the table up
  // vector from the die's CURRENT orientation. We intentionally preserve the
  // die's existing yaw instead of rotating artwork toward the camera. That
  // removes the unnatural last-second twist seen in v0.7.1.
  const localNormal = geometry.faceNormals[faceIndex];
  const worldNormal = quatRotateVec3(currentRotation, localNormal);
  const correction = quatFromTo(worldNormal, UP);
  return quatMultiply(correction, currentRotation);
}

function guideResultFace(entry, dt, simulationElapsedMs) {
  // Preserve the signature free-physics opening. Only once a die has already
  // hit the table and the throw is entering its late rolling phase do we begin
  // a progressive, torque-only attraction toward the authoritative result face.
  // No yaw target is imposed: the die keeps its natural player-facing rotation.
  if (!entry.firstFloorImpact) return;

  const guideStart = entry.delay + Math.max(
    GUIDED_SETTLE.freePhysicsMs,
    entry.rollProfile.guideAfterMs - GUIDED_SETTLE.guideLeadMs
  );
  if (simulationElapsedMs < guideStart) return;

  const horizontalSpeed = Math.hypot(entry.velocity[0], entry.velocity[2]);
  const verticalSpeed = Math.abs(entry.velocity[1]);
  if (horizontalSpeed > GUIDED_SETTLE.maxHorizontalSpeed
    || verticalSpeed > GUIDED_SETTLE.maxVerticalSpeed) return;

  const { angle, axisX, axisZ } = resultFaceError(entry);
  if (angle < 0.006) return;

  const railReached = (entry.rightWallHits ?? 0) > 0;
  const timeRamp = clamp((simulationElapsedMs - guideStart) / 700, 0, 1);
  const energyRamp = clamp(
    (GUIDED_SETTLE.maxHorizontalSpeed - horizontalSpeed) / GUIDED_SETTLE.maxHorizontalSpeed,
    0,
    1
  );
  const deadlineRamp = clamp(
    (simulationElapsedMs - (entry.rollProfile.maxSimulationMs - 650)) / 650,
    0,
    1
  );

  // Rail Rebound keeps only a very weak pre-rail bias so its signature edge hit
  // still reads naturally. Scatter and Deep Bounce may start guiding a little
  // earlier because they are allowed to settle without touching the right rail.
  const pathScale = railReached
    ? 1
    : entry.rollProfile.requireRailForSleep ? 0.26 : 0.48;
  const strength = pathScale
    * (0.12 + timeRamp * 0.48 + deadlineRamp * 0.40)
    * (0.22 + energyRamp * 0.78);
  if (strength <= 0.001) return;

  // Blend angular velocity toward the shortest face-up roll axis instead of
  // rotating the quaternion directly. This keeps the correction inside the
  // visible physical motion rather than producing a presentation snap.
  const targetAngularSpeed = Math.min(
    8.8,
    angle * (4.0 + deadlineRamp * 3.4)
  );
  const currentAlongAxis = entry.angularVelocity[0] * axisX
    + entry.angularVelocity[2] * axisZ;
  const velocityBlend = clamp(dt * (1.4 + strength * 4.2), 0, 0.12);
  const angularCorrection = (targetAngularSpeed - currentAlongAxis)
    * velocityBlend
    * strength;
  entry.angularVelocity[0] += axisX * angularCorrection;
  entry.angularVelocity[2] += axisZ * angularCorrection;

  // Remove only a small amount of sideways tumble that fights the target roll.
  // Vertical-axis spin is intentionally untouched so every die retains natural
  // yaw and the three motion profiles remain visibly distinct.
  const perpX = -axisZ;
  const perpZ = axisX;
  const perpendicularSpeed = entry.angularVelocity[0] * perpX
    + entry.angularVelocity[2] * perpZ;
  const perpendicularDamping = clamp(dt * (0.18 + strength * 0.85), 0, 0.035);
  entry.angularVelocity[0] -= perpX * perpendicularSpeed * perpendicularDamping;
  entry.angularVelocity[2] -= perpZ * perpendicularSpeed * perpendicularDamping;

  // A smooth late torque closes the remaining angle before the die appears to
  // stop. Near the profile deadline the assistance rises, but only while the
  // die is still in the physics phase.
  const torque = Math.min(
    12.0,
    angle * (5.2 + deadlineRamp * 4.2)
  ) * strength;
  entry.angularVelocity[0] += axisX * torque * dt;
  entry.angularVelocity[2] += axisZ * torque * dt;

  // v0.7.16 smooth deterministic face acquisition. The target face is acquired
  // over many visible physics frames. No one-frame safety rotation is allowed.
  const hardAssistStart = entry.rollProfile.maxSimulationMs + GUIDED_SETTLE.hardAssistStartMs;
  if (simulationElapsedMs >= hardAssistStart && angle > GUIDED_SETTLE.settleFaceAngle) {
    const overtime = clamp((simulationElapsedMs - hardAssistStart) / GUIDED_SETTLE.terminalAssistMs, 0, 1);
    const targetRotation = buildFaceUpTargetRotation(entry.mesh.geometry, entry.die.faceIndex, entry.rotation);
    const assist = clamp(
      dt * GUIDED_SETTLE.hardAssistRate * (0.42 + overtime * 0.58),
      0,
      GUIDED_SETTLE.hardAssistMaxStep
    );
    entry.rotation = quatSlerp(entry.rotation, targetRotation, assist);

    const angularDamping = Math.pow(0.12, dt);
    const travelDamping = Math.pow(0.22, dt);
    entry.angularVelocity[0] *= angularDamping;
    entry.angularVelocity[1] *= angularDamping;
    entry.angularVelocity[2] *= angularDamping;
    entry.velocity[0] *= travelDamping;
    entry.velocity[2] *= travelDamping;
  }
}

function restingHeight(geometry, rotation, scale) {
  let minY = Infinity;
  for (const vertex of geometry.vertices) {
    const transformed = quatRotateVec3(rotation, vertex);
    minY = Math.min(minY, transformed[1] * scale);
  }
  return GROUND_Y - minY;
}

function previewPayload() {
  return {
    rollId: `preview-${Date.now()}`,
    dice: [
      { type: "boost", faceIndex: 2 },
      { type: "setback", faceIndex: 4 },
      { type: "ability", faceIndex: 6 },
      { type: "difficulty", faceIndex: 5 },
      { type: "proficiency", faceIndex: 11 },
      { type: "challenge", faceIndex: 11 }
    ],
    totals: {},
    net: {},
    context: { preview: true }
  };
}

export class WebGLDiceRenderer {
  constructor({ debug = false, themeId = "fantasy" } = {}) {
    this.debug = debug;
    this.themeId = themeId;
    this.canvas = null;
    this.gl = null;
    this.theme = null;
    this.meshes = new Map();
    this.symbolMeshes = new Map();
    this.artworkTextures = new Map();
    this.shadowMesh = null;
    this.programs = {};
    this.runningFrame = null;
    this.activeDice = [];
    this.animationResolve = null;
    this.initialized = false;
    this.destroyed = false;
    this.resizeHandler = () => this.resize();
  }

  async initialize() {
    if (this.initialized) return;
    this.theme = await loadTheme(this.themeId);
    this.canvas = document.createElement("canvas");
    this.canvas.id = "genesys-dice-forge-overlay";
    this.canvas.setAttribute("aria-hidden", "true");
    // Dice presentation is intentionally a top-level visual layer. Foundry
    // Application windows can move through large z-index ranges, so relying
    // on normal window stacking can hide dice behind sheets/dialogs. Keep the
    // WebGL canvas above Foundry UI while remaining click-through.
    Object.assign(this.canvas.style, {
      position: "fixed",
      inset: "0",
      width: "100vw",
      height: "100vh",
      pointerEvents: "none",
      zIndex: "2147483646",
      background: "transparent"
    });
    getViewportHost().appendChild(this.canvas);

    const gl = this.canvas.getContext("webgl", {
      alpha: true,
      antialias: true,
      premultipliedAlpha: true,
      preserveDrawingBuffer: false
    });
    if (!gl) throw new Error("[Genesys Dice Forge] WebGL is unavailable in this client.");
    this.gl = gl;

    this.programs.die = createProgram(gl, DIE_VERTEX_SHADER, DIE_FRAGMENT_SHADER);
    this.programs.edge = createProgram(gl, EDGE_VERTEX_SHADER, EDGE_FRAGMENT_SHADER);
    this.programs.shadow = createProgram(gl, SHADOW_VERTEX_SHADER, SHADOW_FRAGMENT_SHADER);
    this.programs.symbol = createProgram(gl, SYMBOL_VERTEX_SHADER, SYMBOL_FRAGMENT_SHADER);

    for (const shape of ["d6", "d8", "d12"]) {
      this.meshes.set(shape, createMesh(gl, getShapeGeometry(shape)));
    }
    for (const type of ["boost", "setback", "ability", "difficulty", "proficiency", "challenge"]) {
      const data = buildDieSymbolLines(type, { specialOnly: true });
      this.symbolMeshes.set(type, {
        position: createArrayBuffer(gl, data),
        vertexCount: data.length / 3
      });
      const material = this.theme.dice[type];
      this.artworkTextures.set(type, await createDieArtworkTexture(gl, type, material));
    }
    this.shadowMesh = createShadowMesh(gl);

    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.BACK);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

    window.addEventListener("resize", this.resizeHandler, { passive: true });
    this.resize();
    this.clear();
    this.initialized = true;

    if (this.debug) console.log("[Genesys Dice Forge] WebGL renderer initialized.");
  }

  get capabilities() {
    return {
      renderer3d: true,
      renderer: "native-webgl",
      proceduralGeometry: true,
      deterministicFacePlayback: true,
      shadows: true,
      engravedSymbols: true,
      signatureEffects: true,
      artworkFaceAtlases: true,
      signatureGlyphArtwork: true,
      physics: "overhand-drop-table-roll"
    };
  }

  resize() {
    if (!this.canvas || !this.gl) return;
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.floor(window.innerWidth * ratio));
    const height = Math.max(1, Math.floor(window.innerHeight * ratio));
    if (this.canvas.width !== width || this.canvas.height !== height) {
      this.canvas.width = width;
      this.canvas.height = height;
      this.canvas.style.width = `${window.innerWidth}px`;
      this.canvas.style.height = `${window.innerHeight}px`;
    }
    this.gl.viewport(0, 0, width, height);
  }

  clear() {
    if (!this.gl) return;
    this.gl.clearColor(0, 0, 0, 0);
    this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);
  }

  async setTheme(themeId) {
    this.theme = await loadTheme(themeId);
    this.themeId = themeId;
    if (this.gl) {
      for (const artwork of this.artworkTextures.values()) {
        if (artwork?.texture) this.gl.deleteTexture(artwork.texture);
      }
      this.artworkTextures.clear();
      for (const type of ["boost", "setback", "ability", "difficulty", "proficiency", "challenge"]) {
        this.artworkTextures.set(type, await createDieArtworkTexture(this.gl, type, this.theme.dice[type]));
      }
    }
  }

  async preview() {
    return this.animate(previewPayload());
  }

  async animate(payload) {
    if (!this.initialized || this.destroyed) {
      return { rendered: false, reason: "renderer-not-ready" };
    }

    if (this.runningFrame) cancelAnimationFrame(this.runningFrame);
    if (this.animationResolve) {
      this.animationResolve({ rendered: false, reason: "superseded" });
      this.animationResolve = null;
    }

    const dice = payload.dice.slice();
    const rollKey = payload.rollId ?? `${Date.now()}`;
    const seed = hashString(rollKey);
    const random = mulberry32(seed);
    // Separate RNG stream: selecting a profile must not change the familiar
    // upper-left release or the per-die launch variation.
    const profileRandom = mulberry32(hashString(`${rollKey}:motion-profile`));
    const rollProfile = chooseRollProfile(profileRandom);
    const startTime = performance.now();

    if (this.debug) {
      console.debug(`[Genesys Dice Forge] Motion profile: ${rollProfile.id}`, {
        rollId: payload.rollId,
        profile: rollProfile.id,
        dice: dice.length
      });
    }

    this.activeDice = dice.map((die, index) => {
      const definition = getDieDefinition(die.type);
      const mesh = this.meshes.get(definition.shape);
      const scale = definition.shape === "d12" ? 0.38 : definition.shape === "d8" ? 0.35 : 0.33;
      const physics = shapePhysics(definition.shape);
      const targetRotation = null;
      const collisionRadius = geometryRadius(mesh.geometry, scale);

      const spawnZ = clamp(
        -1.28 + (random() - 0.5) * 1.25 + ((index % 4) - 1.5) * 0.055,
        TABLE.minZ + collisionRadius,
        TABLE.maxZ - collisionRadius
      );
      const initialRotation = quatMultiply(
        quatFromAxisAngle([random() - 0.5, random() - 0.5, 0.75 + random()], random() * Math.PI * 2),
        quatFromAxisAngle([0.18 + random(), 0.20 + random(), 0.45 + random()], random() * Math.PI * 2)
      );
      const startFloorY = GROUND_Y - bottomOffsetY(mesh.geometry, initialRotation, scale);

      // Overhand handful: high upper-left release, already falling toward the
      // desktop, with a strong rightward throw and positive-Z motion toward
      // the player's viewpoint. Larger dice are a touch slower but carry more
      // angular momentum.
      const shapeSpeed = definition.shape === "d12" ? -0.24 : definition.shape === "d6" ? 0.14 : 0;
      const vx = 8.65 + shapeSpeed + (random() - 0.5) * 1.35;
      const vy = -0.55 - random() * 1.25;
      const vz = 1.55 + random() * 1.30 + (random() - 0.5) * 0.35;
      const angularMagnitude = 13.5 + random() * 10.0;
      const angularAxis = [
        (random() - 0.5) * 0.65,
        (random() - 0.5) * 0.45,
        -0.72 - random() * 0.48
      ];
      const angularLength = Math.max(0.001, Math.hypot(...angularAxis));

      return {
        die,
        definition,
        mesh,
        scale,
        physics,
        rollProfile,
        collisionRadius,
        targetRotation,
        rotation: initialRotation,
        position: [
          TABLE.spawnX - random() * 0.52 - Math.floor(index / 10) * 0.08,
          startFloorY + 2.25 + random() * 0.82,
          spawnZ
        ],
        velocity: [vx, vy, vz],
        angularVelocity: angularAxis.map((v) => v / angularLength * angularMagnitude),
        impactTwist: [random() - 0.5, random() - 0.5, random() - 0.5],
        profileLateralSign: random() < 0.5 ? -1 : 1,
        profileLateralAmount: random(),
        firstFloorImpact: false,
        delay: index * 18 + (index % 3) * 5,
        opacity: 0,
        settleFromRotation: null,
        settleFromPosition: null,
        finalPosition: null,
        rightWallHits: 0
      };
    });

    return new Promise((resolve) => {
      this.animationResolve = resolve;
      let lastFrame = startTime;
      let phase = "physics";
      let settleStart = 0;
      let holdStart = 0;

      const beginSettle = (now) => {
        phase = "settle";
        settleStart = now;
        for (const entry of this.activeDice) {
          entry.velocity = [0, 0, 0];
          entry.angularVelocity = [0, 0, 0];
          entry.settleFromRotation = Array.isArray(entry.rotation) ? [...entry.rotation] : [0, 0, 0, 1];
          entry.settleFromPosition = [...entry.position];
          entry.targetRotation = entry.settleFromRotation;
          entry.displayTopFaceIndex = topPhysicalFaceIndex(entry);
          const finalY = restingHeight(entry.mesh.geometry, entry.settleFromRotation, entry.scale);
          entry.finalPosition = [entry.position[0], finalY, entry.position[2]];
        }
      };

      const frame = (now) => {
        const elapsed = now - startTime;
        let delta = Math.min(PHYSICS.maxFrameDelta, Math.max(0, (now - lastFrame) / 1000));
        lastFrame = now;

        if (phase === "physics") {
          // Fixed substeps make bounces/collisions behave similarly at 60/120Hz
          // and across Foundry clients with uneven frame pacing.
          while (delta > 0.00001) {
            const dt = Math.min(PHYSICS.fixedStep, delta);
            for (const entry of this.activeDice) stepDie(entry, dt, elapsed);
            resolveRigidDiceContacts(this.activeDice, elapsed);
            for (const entry of this.activeDice) applyTableBounds(entry);
            delta -= dt;
          }

          this.draw(this.activeDice);

          const allSleeping = elapsed >= PHYSICS.minSimulationMs
            && this.activeDice.every((entry) => dieIsNearlySleeping(entry, elapsed));
          // Do not cut directly from free rotation into a large deterministic
          // correction at the old hard timeout. Give Guided Settle a brief
          // physics-only grace period to finish orienting the result naturally.
          const naturalTimeout = elapsed >= rollProfile.maxSimulationMs + 700;

          // v0.7.17: settle based only on physical energy/time. The authoritative
          // Genesys result is mapped onto the polygon that naturally landed up.
          if (allSleeping || naturalTimeout) beginSettle(now);
        } else if (phase === "settle") {
          const t = clamp((now - settleStart) / PHYSICS.settleMs);
          // v0.7.10: result orientation is completed during physical guidance.
          // Never rotate after the roll has visually stopped; this removes the final twist.
          const eased = 0;
          const states = this.activeDice.map((entry) => {
            const y = entry.settleFromPosition[1]
              + (entry.finalPosition[1] - entry.settleFromPosition[1]) * eased;
            const position = [entry.finalPosition[0], y, entry.finalPosition[2]];
            const rotation = entry.settleFromRotation ?? entry.rotation ?? [0, 0, 0, 1];

            // No presentation-only yaw or micro-rock here. Any visible motion at
            // this point is solely the shortest remaining face-up correction.
            // The physical phase already supplied bounce, roll and wobble.
            entry.position = position;
            entry.rotation = rotation;
            entry.opacity = 1;
            return entry;
          });
          this.draw(states);

          if (t >= 1) {
            phase = "hold";
            holdStart = now;
            for (const entry of this.activeDice) {
              // v0.7.11: hold exactly the last rendered physical pose. Do not snap
              // to targetRotation when settle completes. That snap was the last knyck.
              entry.position = [...entry.position];
              entry.rotation = Array.isArray(entry.rotation) ? [...entry.rotation] : [0, 0, 0, 1];
              entry.opacity = 1;
            }
          }
        } else {
          this.draw(this.activeDice);
          if (now - holdStart >= PHYSICS.holdMs) {
            this.runningFrame = null;
            const resolver = this.animationResolve;
            this.animationResolve = null;
            setTimeout(() => this.fadeAndClear(320), 80);
            resolver?.({
              rendered: true,
              renderer: "native-webgl",
              dice: dice.length,
              tableRoll: true,
              rigidBodyTablePhysics: true,
              overhandDrop: true,
              rightRailRebound: rollProfile.id === "rail-rebound",
              motionProfile: rollProfile.id,
              deterministicFaces: true,
              guidedSettle: true,
              playerReadableTopFaces: true
            });
            return;
          }
        }

        this.runningFrame = requestAnimationFrame(frame);
      };

      this.runningFrame = requestAnimationFrame(frame);
    });
  }

  fadeAndClear(duration = 250) {
    if (!this.activeDice.length || this.destroyed) return;
    const snapshot = this.activeDice.map((entry) => ({
      ...entry,
      position: [...entry.position],
      rotation: Array.isArray(entry.rotation) ? [...entry.rotation] : [0, 0, 0, 1],
      opacity: 1
    }));
    const start = performance.now();
    const frame = (now) => {
      const t = clamp((now - start) / duration);
      const opacity = 1 - t;
      this.draw(snapshot.map((entry) => ({ ...entry, opacity })));
      if (t < 1) requestAnimationFrame(frame);
      else {
        this.activeDice = [];
        this.clear();
      }
    };
    requestAnimationFrame(frame);
  }

  draw(states) {
    const gl = this.gl;
    if (!gl) return;
    this.resize();
    this.clear();

    const aspect = this.canvas.width / this.canvas.height;
    const projection = mat4Perspective(35 * Math.PI / 180, aspect, 0.1, 100);
    const view = mat4LookAt(CAMERA_POSITION, CAMERA_TARGET);
    const viewProjection = mat4Multiply(projection, view);

    this.drawShadows(states, viewProjection);
    for (const state of states) {
      if (state.opacity <= 0) continue;
      this.drawDie(state, viewProjection);
    }
  }

  drawShadows(states, viewProjection) {
    const gl = this.gl;
    const program = this.programs.shadow;
    gl.useProgram(program);
    gl.disable(gl.CULL_FACE);
    gl.depthMask(false);
    bindAttribute(gl, program, "aPosition", this.shadowMesh.position, 3);
    bindAttribute(gl, program, "aUv", this.shadowMesh.uv, 2);
    gl.uniformMatrix4fv(uniformLocation(gl, program, "uViewProjection"), false, viewProjection);

    for (const state of states) {
      const height = Math.max(0, state.position[1] - GROUND_Y);
      const spread = 1.1 + Math.min(1.1, height * 0.12);
      const shadowScale = state.scale * spread;
      const model = mat4FromRotationTranslationScale([0, 0, 0, 1], [state.position[0], GROUND_Y + 0.006, state.position[2]], shadowScale);
      gl.uniformMatrix4fv(uniformLocation(gl, program, "uModel"), false, model);
      gl.uniform1f(uniformLocation(gl, program, "uOpacity"), state.opacity * (0.34 / (1 + height * 0.22)));
      gl.drawArrays(gl.TRIANGLES, 0, this.shadowMesh.vertexCount);
    }

    gl.depthMask(true);
    gl.enable(gl.CULL_FACE);
  }

  drawDie(state, viewProjection) {
    const gl = this.gl;
    const material = this.theme.dice[state.die.type];
    const baseColor = hexToRgb01(material.base);
    const edgeColor = hexToRgb01(material.edge);
    const model = mat4FromRotationTranslationScale(state.rotation, state.position, state.scale);

    const dieProgram = this.programs.die;
    gl.useProgram(dieProgram);
    bindAttribute(gl, dieProgram, "aPosition", state.mesh.position, 3);
    bindAttribute(gl, dieProgram, "aNormal", state.mesh.normal, 3);
    bindAttribute(gl, dieProgram, "aFaceIndex", state.mesh.faceIndex, 1);
    bindAttribute(gl, dieProgram, "aFaceUv", state.mesh.faceUv, 2);
    gl.uniformMatrix4fv(uniformLocation(gl, dieProgram, "uModel"), false, model);
    gl.uniformMatrix4fv(uniformLocation(gl, dieProgram, "uViewProjection"), false, viewProjection);
    gl.uniform3fv(uniformLocation(gl, dieProgram, "uBaseColor"), baseColor);
    gl.uniform3fv(uniformLocation(gl, dieProgram, "uEdgeTint"), edgeColor);
    gl.uniform3fv(uniformLocation(gl, dieProgram, "uCameraPosition"), CAMERA_POSITION);
    gl.uniform3fv(uniformLocation(gl, dieProgram, "uLightDirection"), [-0.45, -1.0, -0.3]);
    gl.uniform1f(uniformLocation(gl, dieProgram, "uTargetFaceIndex"), state.die.faceIndex);
    gl.uniform1f(uniformLocation(gl, dieProgram, "uDisplayTopFaceIndex"), state.displayTopFaceIndex ?? state.die.faceIndex);
    gl.uniform1f(uniformLocation(gl, dieProgram, "uAuthoritativeFaceIndex"), state.die.faceIndex);
    gl.uniform1f(uniformLocation(gl, dieProgram, "uOpacity"), state.opacity);
    gl.uniform1f(uniformLocation(gl, dieProgram, "uRoughness"), material.roughness ?? 0.55);
    gl.uniform1f(uniformLocation(gl, dieProgram, "uMetallic"), material.metallic ?? 0.16);
    gl.uniform1f(uniformLocation(gl, dieProgram, "uGrain"), material.grain ?? 0.10);
    const artwork = this.artworkTextures.get(state.die.type);
    if (artwork?.texture) {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, artwork.texture);
      gl.uniform1i(uniformLocation(gl, dieProgram, "uArtworkTexture"), 0);
      gl.uniform2f(uniformLocation(gl, dieProgram, "uArtworkGrid"), artwork.cols, artwork.rows);
      gl.uniform1f(uniformLocation(gl, dieProgram, "uArtworkStrength"), material.artworkStrength ?? 1.0);
    } else {
      gl.uniform2f(uniformLocation(gl, dieProgram, "uArtworkGrid"), 1, 1);
      gl.uniform1f(uniformLocation(gl, dieProgram, "uArtworkStrength"), 0.0);
    }
    gl.drawArrays(gl.TRIANGLES, 0, state.mesh.triangleVertexCount);

    const edgeProgram = this.programs.edge;
    gl.useProgram(edgeProgram);
    bindAttribute(gl, edgeProgram, "aPosition", state.mesh.edge, 3);
    gl.uniformMatrix4fv(uniformLocation(gl, edgeProgram, "uModel"), false, model);
    gl.uniformMatrix4fv(uniformLocation(gl, edgeProgram, "uViewProjection"), false, viewProjection);
    gl.uniform3fv(uniformLocation(gl, edgeProgram, "uColor"), edgeColor);
    gl.uniform1f(uniformLocation(gl, edgeProgram, "uInflate"), 1.014);
    gl.uniform1f(uniformLocation(gl, edgeProgram, "uOpacity"), state.opacity * 0.95);
    gl.drawArrays(gl.LINES, 0, state.mesh.edgeVertexCount);

    const symbolMesh = this.symbolMeshes.get(state.die.type);
    const visibleSpecials = getFaceSymbols(state.die.type, state.die.faceIndex);
    const signatureResult = visibleSpecials.includes("triumph") || visibleSpecials.includes("despair");
    const hasSignature = signatureResult && (state.displayTopFaceIndex ?? state.die.faceIndex) === state.die.faceIndex;
    if (hasSignature && symbolMesh?.vertexCount) {
      const symbolProgram = this.programs.symbol;
      // The face glyph obeys the die-specific black/light contrast palette.
      // Signature glow is a separate emissive accent so a black Despair glyph
      // on the red Challenge die can remain readable without changing its
      // locked face color.
      const signatureColor = visibleSpecials.includes("triumph") ? "#ffd66e" : "#e35f46";
      const symbolColor = hexToRgb01(signatureColor);
      gl.useProgram(symbolProgram);
      bindAttribute(gl, symbolProgram, "aPosition", symbolMesh.position, 3);
      gl.uniformMatrix4fv(uniformLocation(gl, symbolProgram, "uModel"), false, model);
      gl.uniformMatrix4fv(uniformLocation(gl, symbolProgram, "uViewProjection"), false, viewProjection);
      gl.uniform3fv(uniformLocation(gl, symbolProgram, "uColor"), symbolColor);
      gl.uniform1f(uniformLocation(gl, symbolProgram, "uOpacity"), state.opacity * 0.72);
      gl.uniform1f(uniformLocation(gl, symbolProgram, "uGlow"), 0.82);
      gl.drawArrays(gl.LINES, 0, symbolMesh.vertexCount);
    }
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    if (this.runningFrame) cancelAnimationFrame(this.runningFrame);
    window.removeEventListener("resize", this.resizeHandler);
    if (this.gl) {
      for (const artwork of this.artworkTextures.values()) {
        if (artwork?.texture) this.gl.deleteTexture(artwork.texture);
      }
    }
    this.artworkTextures.clear();
    this.canvas?.remove();
    this.canvas = null;
    this.gl = null;
    this.activeDice = [];
  }
}
