const TYPE_ALIASES = new Map([
  ["b", "boost"], ["boost", "boost"], ["boostdie", "boost"], ["boostdice", "boost"],
  ["s", "setback"], ["setback", "setback"], ["setbackdie", "setback"], ["setbackdice", "setback"],
  ["a", "ability"], ["ability", "ability"], ["abilitydie", "ability"], ["abilitydice", "ability"],
  ["d", "difficulty"], ["difficulty", "difficulty"], ["difficultydie", "difficulty"], ["difficultydice", "difficulty"],
  ["p", "proficiency"], ["proficiency", "proficiency"], ["proficiencydie", "proficiency"], ["proficiencydice", "proficiency"],
  ["c", "challenge"], ["challenge", "challenge"], ["challengeddie", "challenge"], ["challengedice", "challenge"], ["challengedie", "challenge"]
]);

const SIDES = Object.freeze({ boost: 6, setback: 6, ability: 8, difficulty: 8, proficiency: 12, challenge: 12 });
const COMMON_HOOKS = Object.freeze([
  "genesysRollResolved",
  "genesysCheckResolved",
  "genesysRollComplete",
  "genesysDiceRolled",
  "genesysResolvedRoll"
]);

function compact(value) {
  return String(value ?? "").toLowerCase().replace(/[^a-z]/g, "");
}

function normalizeType(value) {
  const key = compact(value);
  if (!key) return null;
  if (TYPE_ALIASES.has(key)) return TYPE_ALIASES.get(key);
  for (const [alias, type] of TYPE_ALIASES) {
    if (alias.length > 1 && key.includes(alias)) return type;
  }
  return null;
}

function isGenesysGameSystem() {
  const id = String(game?.system?.id ?? "").toLowerCase();
  const title = String(game?.system?.title ?? "").toLowerCase();
  return id.includes("genesys") || title.includes("genesys");
}

function integerValue(value) {
  if (Number.isInteger(value)) return value;
  if (typeof value === "string" && /^\d+$/.test(value.trim())) return Number(value.trim());
  return null;
}

function faceIndexFromIndex(value, type) {
  if (!type) return null;
  const n = integerValue(value);
  return n != null && n >= 0 && n < SIDES[type] ? n : null;
}

function faceIndexFromFaceNumber(value, type) {
  if (!type) return null;
  const n = integerValue(value);
  if (n == null) return null;
  if (n >= 1 && n <= SIDES[type]) return n - 1;
  if (n === 0) return 0;
  return null;
}

function readDieObject(obj) {
  if (!obj || typeof obj !== "object") return null;
  const type = normalizeType(
    obj.type ?? obj.dieType ?? obj.diceType ?? obj.kind ?? obj.name ?? obj.code ?? obj.denomination ?? obj.flavor
  );
  if (!type) return null;

  const explicitIndex = obj.faceIndex ?? obj.face_index ?? obj.index ?? obj.resultIndex ?? obj.result_index;
  let faceIndex = faceIndexFromIndex(explicitIndex, type);
  if (faceIndex == null) faceIndex = faceIndexFromIndex(obj.result?.faceIndex ?? obj.result?.index, type);
  if (faceIndex == null) faceIndex = faceIndexFromFaceNumber(obj.face ?? obj.value ?? obj.result?.result ?? (typeof obj.result === "number" ? obj.result : null), type);
  if (faceIndex == null) return null;
  const die = { type, faceIndex };
  if (obj.rawSymbols && typeof obj.rawSymbols === "object") die.rawSymbols = obj.rawSymbols;
  return die;
}

function findDiceArray(root, maxDepth = 6) {
  const seen = new Set();
  function walk(value, depth) {
    if (depth > maxDepth || value == null || typeof value !== "object" || seen.has(value)) return null;
    seen.add(value);
    if (Array.isArray(value)) {
      const parsed = value.map(readDieObject).filter(Boolean);
      if (parsed.length && parsed.length === value.filter((item) => item && typeof item === "object").length) return parsed;
      for (const item of value) {
        const nested = walk(item, depth + 1);
        if (nested?.length) return nested;
      }
      return null;
    }
    const priorityKeys = ["dice", "rolledDice", "rollDice", "physicalDice", "dieResults", "results"];
    for (const key of priorityKeys) {
      if (Array.isArray(value[key])) {
        const parsed = value[key].map(readDieObject).filter(Boolean);
        if (parsed.length) return parsed;
      }
    }
    for (const child of Object.values(value)) {
      const nested = walk(child, depth + 1);
      if (nested?.length) return nested;
    }
    return null;
  }
  return walk(root, 0);
}

function typeFromTerm(term) {
  const candidates = [
    term?.options?.type,
    term?.options?.dieType,
    term?.options?.flavor,
    term?.denomination,
    term?.constructor?.DENOMINATION,
    term?.constructor?.name
  ];
  for (const candidate of candidates) {
    const type = normalizeType(candidate);
    if (type) return type;
  }
  return null;
}

function diceFromRollTerms(rolls) {
  const dice = [];
  const queue = Array.isArray(rolls) ? [...rolls] : rolls ? [rolls] : [];
  for (const roll of queue) {
    const terms = Array.isArray(roll?.terms) ? roll.terms : [];
    for (const term of terms) {
      const type = typeFromTerm(term);
      if (!type || !Array.isArray(term?.results)) continue;
      for (const result of term.results) {
        if (result?.active === false) continue;
        let faceIndex = faceIndexFromIndex(result?.faceIndex ?? result?.index, type);
        if (faceIndex == null) faceIndex = faceIndexFromFaceNumber(result?.result, type);
        if (faceIndex != null) dice.push({ type, faceIndex });
      }
    }
  }
  return dice;
}

function diceFromContent(content) {
  if (typeof content !== "string" || !content.includes("data-")) return [];
  try {
    const template = document.createElement("template");
    template.innerHTML = content;
    const out = [];
    for (const el of template.content.querySelectorAll("[data-die-type], [data-dice-type]")) {
      const type = normalizeType(el.dataset.dieType ?? el.dataset.diceType);
      if (!type) continue;
      let faceIndex = faceIndexFromIndex(el.dataset.faceIndex, type);
      if (faceIndex == null) faceIndex = faceIndexFromFaceNumber(el.dataset.face ?? el.dataset.result, type);
      if (faceIndex != null) out.push({ type, faceIndex });
    }
    return out;
  } catch (_) {
    return [];
  }
}

function buildPayload(source, dice, origin) {
  if (!dice?.length) return null;
  const id = source?.id ?? source?._id ?? source?.rollId ?? source?.checkId ?? `${origin}-${Date.now()}`;
  return {
    rollId: `auto-${id}`,
    dice,
    totals: source?.totals ?? source?.result?.totals ?? {},
    net: source?.net ?? source?.result?.net ?? {},
    context: {
      source: "genesys-auto-bridge",
      origin,
      actorId: source?.actorId ?? source?.actor?.id ?? source?.speaker?.actor ?? null,
      messageId: source?.id ?? source?._id ?? null
    }
  };
}

function extractFromMessage(message) {
  const plain = typeof message?.toObject === "function" ? message.toObject(false) : message;
  const flagDice = findDiceArray(plain?.flags ?? plain);
  if (flagDice?.length) return buildPayload(plain, flagDice, "chat-flags");

  const rollDice = diceFromRollTerms(message?.rolls ?? plain?.rolls);
  if (rollDice.length) return buildPayload(plain, rollDice, "chat-roll-terms");

  const contentDice = diceFromContent(message?.content ?? plain?.content);
  if (contentDice.length) return buildPayload(plain, contentDice, "chat-content");
  return null;
}

function extractFromHook(args) {
  for (const arg of args) {
    if (!arg || typeof arg !== "object") continue;
    const dice = findDiceArray(arg);
    if (dice?.length) return buildPayload(arg, dice, "system-hook");
  }
  return null;
}

export function installGenesysAutoBridge(api, { moduleId = "genesys-dice-forge" } = {}) {
  if (!api || !isGenesysGameSystem()) return { installed: false, reason: "not-genesys-system" };
  if (!game.settings.get(moduleId, "autoSystemBridge")) return { installed: false, reason: "disabled" };

  const seen = new Set();
  const present = async (payload) => {
    if (!payload?.dice?.length || !api.wantsSystemRollPresentation?.()) return false;
    if (seen.has(payload.rollId)) return false;
    seen.add(payload.rollId);
    if (seen.size > 200) seen.delete(seen.values().next().value);
    try {
      const result = await api.presentResolvedSystemRoll(payload);
      return Boolean(result?.rendered);
    } catch (error) {
      console.warn("[Genesys Dice Forge] Automatic Genesys roll presentation failed.", error, payload);
      return false;
    }
  };

  Hooks.on("createChatMessage", (message) => {
    // Never replay Dice Forge's own standalone simulator chat card.
    if (message?.flags?.[moduleId]?.simulator) return;
    const payload = extractFromMessage(message);
    if (payload) present(payload);
    else if (game.settings.get(moduleId, "debug")) {
      console.debug("[Genesys Dice Forge] Genesys chat message had no recoverable per-die face data; direct system integration is required for this roll.", message);
    }
  });

  for (const hookName of COMMON_HOOKS) {
    Hooks.on(hookName, (...args) => {
      const payload = extractFromHook(args);
      if (payload) present(payload);
    });
  }

  console.info("[Genesys Dice Forge] Automatic Genesys system bridge installed (chat + resolved-roll hooks)." );
  return { installed: true };
}
