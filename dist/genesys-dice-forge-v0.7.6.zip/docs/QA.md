# Genesys Dice Forge v0.5.0 QA

## Install
Install the `genesys-dice-forge` folder as a normal Foundry module and enable it in a V13.351 or V14 test world.

## Fast tabletop test
1. Open **Configure Settings -> Module Settings**.
2. Enable **Genesys Dice Forge: QA / Debug Mode**.
3. Click **TEST DICE**.

Expected: blue/black d6, green/purple d8 and gold/red d12 enter from the left, bounce/roll across the desktop, lose energy, and settle as a result cluster on the right. The gold Proficiency preview must land on Triumph and red Challenge on Despair.

## Exact pool/count test
```js
await game.modules.get("genesys-dice-forge").api.animateRoll({
  rollId: "qa-v050-count-test",
  dice: [
    { type: "boost", faceIndex: 2 },
    { type: "boost", faceIndex: 3 },
    { type: "ability", faceIndex: 7 },
    { type: "ability", faceIndex: 6 },
    { type: "ability", faceIndex: 1 },
    { type: "proficiency", faceIndex: 11 },
    { type: "difficulty", faceIndex: 7 },
    { type: "difficulty", faceIndex: 3 },
    { type: "challenge", faceIndex: 11 },
    { type: "setback", faceIndex: 4 }
  ]
});
```

Expected: all ten supplied dice are rendered with the same types and the supplied faces finish upward.

## Deterministic result test
Repeat the same payload with the same `rollId`. Motion and final placement should be repeatable enough for QA; the result face must always be identical.

## Failure behavior
WebGL failure must not affect Foundry. The module falls back to `NullRenderer` and does not mount into Foundry PIXI canvas groups.


## v0.6.2 Overhand Drop QA
1. Dice should appear from high upper-left, not slide in at table height.
2. Motion should visibly travel down, right, and toward the player's viewpoint before first table contact.
3. Most dice should continue into the right rail and visibly rebound.
4. The rebound should return dice into the visible play area and decay quickly under table friction.
5. Large pools should read as a handful with independent trajectories/collisions.
6. Final face-up symbols must still match the supplied authoritative faceIndex values.
7. GOLD adaptive audio must remain unchanged.

## v0.7.0 Premium Dice Visual QA
1. Boost must read as light blue d6 with black glyphs; Setback as black d6 with light glyphs.
2. Ability must read as green d8 with black glyphs; Difficulty as purple d8 with light glyphs.
3. Proficiency must read as yellow/gold d12 with black glyphs; Challenge as red d12 with black glyphs.
4. Faces should look like polished physical enamel/stone with clean metal trim, not ornate parchment/filigree panels.
5. Blank faces must remain visually blank apart from body material/trim.
6. Two-result faces must visibly contain two separate glyphs; same-symbol doubles and mixed-symbol results must remain distinguishable at normal roll scale.
7. The locked Success/Advantage/Triumph/Failure/Threat/Despair silhouettes must remain recognizable without redesign.
8. Proficiency faceIndex 11 must finish on Triumph; Challenge faceIndex 11 must finish on Despair.
9. v0.6.2 overhand drop/right-rail rebound behavior must be unchanged.
10. GOLD adaptive audio must be unchanged.

## v0.7.1 result-face / simulator QA

1. Roll the six-die TEST DICE preview several times.
2. Confirm the final deterministic settle no longer adds a visible random yaw twist.
3. Confirm every authoritative result face ends physically upward and remains readable during the hold phase.
4. Confirm the face artwork orientation is consistent toward the player rather than randomly rotated around the table normal.
5. Confirm the last motion reads as a tiny physical rock, not a scripted spin.
6. Enable **Show Dice Forge Roller**, open **DICE FORGE**, build mixed pools and verify the exact selected number/type of dice is animated.
7. Verify simulator results match the visible rolled faces and that Triumph adds Success / Despair adds Failure without cancelling the special symbols.
8. Verify **POST RESULT TO CHAT** reflects the simulator net result.
9. Re-check GOLD adaptive audio for variation between repeated identical pools.
