# Genesys Dice Forge - System Integration Contract

Dice Forge must never own Genesys rules resolution. The Genesys system resolves the roll first and supplies deterministic die outcomes to the module.

## System -> Dice Forge

```js
const forge = game.modules.get("genesys-dice-forge")?.api;
await forge?.animateRoll({
  rollId: "uuid-or-message-id",
  dice: [
    { type: "ability", faceIndex: 3, rawSymbols: { success: 2 } },
    { type: "difficulty", faceIndex: 4, rawSymbols: { threat: 1 } }
  ],
  totals: {
    success: 2,
    failure: 0,
    advantage: 0,
    threat: 1,
    triumph: 0,
    despair: 0
  },
  net: { netSuccess: 2, netAdvantage: -1, succeeded: true },
  context: { actorId: null, skillId: null, checkId: null }
});
```

`faceIndex` is zero-based and is the authoritative visual result. The v0.5 tabletop motion is presentation only. Every supplied die is rendered, and every die settles on its supplied face.

## Optional system registration

```js
Hooks.on("genesysDiceForgeInit", (forge) => {
  forge.registerSystemBridge({
    id: game.system.id,
    version: game.system.version,
    getThemeContext: () => ({ profileId: "fantasy" })
  });
});
```

This keeps Foundry-version adapters and 3D rendering outside the Genesys domain/rules engine.

## v0.5 renderer guarantee
The native renderer treats the Foundry viewport as a virtual tabletop. Dice travel left-to-right, but animation state never selects the result. During final settling the renderer converges onto the authoritative `faceIndex` already resolved by Genesys.

## System presentation backend (v0.7.2+)

The preferred integrated-system entry point is `await forge.presentResolvedSystemRoll(payload)`. The custom Genesys system should query `forge.wantsSystemRollPresentation()` and suppress only its native dice animation when Dice Forge handles the presentation. See `GENESYS-SYSTEM-INTEGRATION.md`.

## Standalone simulator API (v0.7.1+)

Dice Forge may also resolve a pool independently for standalone use. This does not replace the authoritative system bridge.

```js
const forge = game.modules.get("genesys-dice-forge")?.api;
const { payload, animation } = forge.rollPool({ ability: 2, difficulty: 2 });
await animation;
```

`payload.dice` contains the generated zero-based `faceIndex` for every physical die. `payload.net` contains `netSuccess`, `netAdvantage`, `succeeded`, `triumph`, and `despair`.

When the custom Genesys system is active, it should continue to resolve its own rules and call `animateRoll(payload)` with authoritative die faces.
