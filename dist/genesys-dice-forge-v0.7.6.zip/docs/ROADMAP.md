# Genesys Dice Forge Roadmap

## v0.1.0 - Foundation - complete
Public API, deterministic payload, V13.351/V14 boundary, six die definitions.

## v0.2.0 - Native 3D Renderer - complete
Independent WebGL overlay, procedural geometry, deterministic face-up playback, camera/light/shadows.

## v0.3.x - Fantasy Dice + Audio - complete
Exact face fixtures, compact fantasy dice artwork, adaptive multi-sample dice audio.

## v0.4.0 - Signature Glyph Visual Pass - complete
Project-locked narrative-result silhouettes, high-resolution fantasy inlay artwork, Triumph/Despair signature treatment.

## v0.5.0 - Deterministic Table Roll - current QA
- Foundry viewport used as a virtual table surface.
- Left-to-right throw direction.
- Low bounce, friction, drift and contact wobble.
- Lightweight multi-die contact separation.
- Full authoritative pool count/type presentation.
- Exact face-up settle assist from Genesys `faceIndex`.

## v0.6.0 - Genesys System Integration
- Consume authoritative rolled-face events from the custom Genesys system.
- Coordinate chat-card reveal timing with 3D settle completion.
- User/GM presentation settings and optional fast/skip mode.

## v0.7+ - Dice Forge Themes & Advanced Physics
- Golarion / Runelords and additional setting-profile skins.
- Optional stronger rigid-body collisions and table-edge presets.
- Quality/performance presets and accessibility options.
