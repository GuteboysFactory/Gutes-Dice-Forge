# Genesys Dice Forge - Custom Genesys System Integration

## Goal
The custom Genesys system remains authoritative for rules. Genesys Dice Forge becomes the default 3D presentation backend for every resolved Genesys roll.

The integration boundary is the resolved per-die result:

1. The system builds the dice pool.
2. The system resolves every physical die to a zero-based `faceIndex`.
3. The system computes raw symbols, cancellation/net result, Triumph and Despair.
4. The system passes that exact payload to Dice Forge.
5. Dice Forge animates exactly those dice and settles each die on the supplied face.
6. The system posts/updates its normal chat card and continues normal rules processing.

Dice Forge must never re-roll an authoritative system roll.

## Preferred system call

```js
const forge = game.modules.get("genesys-dice-forge")?.api;

let forgeHandled = false;
if (forge?.wantsSystemRollPresentation?.()) {
  const presentation = await forge.presentResolvedSystemRoll({
    rollId: resolvedRoll.id,
    dice: resolvedRoll.dice.map((die) => ({
      type: die.type,
      faceIndex: die.faceIndex,
      rawSymbols: die.rawSymbols
    })),
    totals: resolvedRoll.totals,
    net: resolvedRoll.net,
    context: {
      actorId: resolvedRoll.actorId,
      skillId: resolvedRoll.skillId,
      checkId: resolvedRoll.checkId
    }
  });
  forgeHandled = Boolean(presentation?.rendered);
}

if (!forgeHandled) {
  await presentNativeGenesysDice(resolvedRoll);
}

await postGenesysChatCard(resolvedRoll);
```

## One integration point, all rolls
Do not add Dice Forge calls to individual sheet buttons. Route all Genesys checks through one central roll/check service, then call Dice Forge from the single resolved-roll presentation stage. This automatically covers skill checks, combat, opposed checks, initiative, magic, NPC checks and future actions that use the same pipeline.

Recommended application flow:

`Action/Sheet -> CheckBuilder -> GenesysRollService.resolve -> RollPresentationService -> Chat/Effects`

`RollPresentationService` chooses Dice Forge when available and enabled, otherwise the system's native fallback.

## Native presentation suppression
The system should suppress only its own dice animation when `forge.wantsSystemRollPresentation()` is true. It should NOT suppress result calculation, chat cards, damage/strain processing, Story Point transactions, narrative result spending, or any other Genesys rules behavior.

## Face-index requirement
Each die must retain its physical result face. Do not reconstruct visual dice from only net symbols. Multiple different physical rolls can produce the same net result, and Dice Forge needs the actual dice list to reproduce the roll faithfully.

## Fire-and-forget hook
For non-blocking integrations, the system can emit:

```js
Hooks.callAll("genesysDiceForgePresentRoll", payload);
```

The direct API is preferred when the system wants to wait for the 3D presentation before posting or revealing the chat result.

## Failure behavior
Dice Forge is an optional presentation module. If it is missing, disabled, unsupported, or its renderer fails, the Genesys system must continue normally using its native presentation. Rules resolution must never depend on Dice Forge availability.
