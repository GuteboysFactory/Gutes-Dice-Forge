import { getModuleAssetUrl } from "../../compat/foundry.js";

const cache = new Map();

export async function loadTheme(themeId = "fantasy") {
  if (cache.has(themeId)) return cache.get(themeId);
  const url = getModuleAssetUrl(`assets/themes/${themeId}/theme.json`);
  const response = await fetch(url, { cache: "no-cache" });
  if (!response.ok) {
    throw new Error(`[Genesys Dice Forge] Failed to load theme '${themeId}' (${response.status}).`);
  }
  const theme = await response.json();
  cache.set(themeId, theme);
  return theme;
}
