export const EPSILON = 1e-6;

export function clamp(value, min = 0, max = 1) {
  return Math.min(max, Math.max(min, value));
}

export function vec3(x = 0, y = 0, z = 0) {
  return [x, y, z];
}

export function add3(a, b) {
  return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
}

export function sub3(a, b) {
  return [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
}

export function scale3(v, s) {
  return [v[0] * s, v[1] * s, v[2] * s];
}

export function dot3(a, b) {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

export function cross3(a, b) {
  return [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0]
  ];
}

export function length3(v) {
  return Math.hypot(v[0], v[1], v[2]);
}

export function normalize3(v) {
  const length = length3(v);
  if (length < EPSILON) return [0, 0, 0];
  return [v[0] / length, v[1] / length, v[2] / length];
}

export function lerp3(a, b, t) {
  return [
    a[0] + (b[0] - a[0]) * t,
    a[1] + (b[1] - a[1]) * t,
    a[2] + (b[2] - a[2]) * t
  ];
}

export function quatIdentity() {
  return [0, 0, 0, 1];
}

export function quatNormalize(q) {
  const length = Math.hypot(q[0], q[1], q[2], q[3]);
  if (length < EPSILON) return quatIdentity();
  return [q[0] / length, q[1] / length, q[2] / length, q[3] / length];
}

export function quatMultiply(a, b) {
  const [ax, ay, az, aw] = a;
  const [bx, by, bz, bw] = b;
  return quatNormalize([
    aw * bx + ax * bw + ay * bz - az * by,
    aw * by - ax * bz + ay * bw + az * bx,
    aw * bz + ax * by - ay * bx + az * bw,
    aw * bw - ax * bx - ay * by - az * bz
  ]);
}

export function quatFromAxisAngle(axis, radians) {
  const n = normalize3(axis);
  const half = radians * 0.5;
  const s = Math.sin(half);
  return quatNormalize([n[0] * s, n[1] * s, n[2] * s, Math.cos(half)]);
}

export function quatFromTo(from, to) {
  const a = normalize3(from);
  const b = normalize3(to);
  const d = clamp(dot3(a, b), -1, 1);

  if (d > 1 - EPSILON) return quatIdentity();
  if (d < -1 + EPSILON) {
    const fallback = Math.abs(a[0]) < 0.9 ? [1, 0, 0] : [0, 0, 1];
    return quatFromAxisAngle(normalize3(cross3(a, fallback)), Math.PI);
  }

  const axis = cross3(a, b);
  return quatNormalize([axis[0], axis[1], axis[2], 1 + d]);
}

export function quatRotateVec3(q, v) {
  const [x, y, z, w] = q;
  const uv = cross3([x, y, z], v);
  const uuv = cross3([x, y, z], uv);
  return add3(v, add3(scale3(uv, 2 * w), scale3(uuv, 2)));
}

export function mat4Identity() {
  return new Float32Array([
    1, 0, 0, 0,
    0, 1, 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1
  ]);
}

export function mat4Multiply(a, b) {
  const out = new Float32Array(16);
  for (let column = 0; column < 4; column += 1) {
    for (let row = 0; row < 4; row += 1) {
      let sum = 0;
      for (let k = 0; k < 4; k += 1) {
        sum += a[k * 4 + row] * b[column * 4 + k];
      }
      out[column * 4 + row] = sum;
    }
  }
  return out;
}

export function mat4Perspective(fovyRadians, aspect, near, far) {
  const f = 1 / Math.tan(fovyRadians / 2);
  const nf = 1 / (near - far);
  return new Float32Array([
    f / aspect, 0, 0, 0,
    0, f, 0, 0,
    0, 0, (far + near) * nf, -1,
    0, 0, 2 * far * near * nf, 0
  ]);
}

export function mat4LookAt(eye, target, up = [0, 1, 0]) {
  const z = normalize3(sub3(eye, target));
  const x = normalize3(cross3(up, z));
  const y = cross3(z, x);

  return new Float32Array([
    x[0], y[0], z[0], 0,
    x[1], y[1], z[1], 0,
    x[2], y[2], z[2], 0,
    -dot3(x, eye), -dot3(y, eye), -dot3(z, eye), 1
  ]);
}

export function mat4FromRotationTranslationScale(q, position, scale = 1) {
  const [x, y, z, w] = quatNormalize(q);
  const x2 = x + x;
  const y2 = y + y;
  const z2 = z + z;
  const xx = x * x2;
  const xy = x * y2;
  const xz = x * z2;
  const yy = y * y2;
  const yz = y * z2;
  const zz = z * z2;
  const wx = w * x2;
  const wy = w * y2;
  const wz = w * z2;

  return new Float32Array([
    (1 - (yy + zz)) * scale, (xy + wz) * scale, (xz - wy) * scale, 0,
    (xy - wz) * scale, (1 - (xx + zz)) * scale, (yz + wx) * scale, 0,
    (xz + wy) * scale, (yz - wx) * scale, (1 - (xx + yy)) * scale, 0,
    position[0], position[1], position[2], 1
  ]);
}

export function easeOutCubic(t) {
  return 1 - Math.pow(1 - clamp(t), 3);
}

export function easeOutQuint(t) {
  return 1 - Math.pow(1 - clamp(t), 5);
}

export function hexToRgb01(hex) {
  const normalized = String(hex).replace("#", "").trim();
  const value = Number.parseInt(normalized.length === 3
    ? normalized.split("").map((c) => c + c).join("")
    : normalized, 16);
  if (!Number.isFinite(value)) return [1, 1, 1];
  return [
    ((value >> 16) & 255) / 255,
    ((value >> 8) & 255) / 255,
    (value & 255) / 255
  ];
}

export function hashString(input) {
  let hash = 2166136261 >>> 0;
  for (let i = 0; i < String(input).length; i += 1) {
    hash ^= String(input).charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

export function mulberry32(seed) {
  let value = seed >>> 0;
  return () => {
    value += 0x6D2B79F5;
    let t = value;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function smoothstep(edge0, edge1, value) {
  if (Math.abs(edge1 - edge0) < EPSILON) return value < edge0 ? 0 : 1;
  const t = clamp((value - edge0) / (edge1 - edge0));
  return t * t * (3 - 2 * t);
}

export function quatSlerp(a, b, t) {
  const qa = quatNormalize(a);
  let qb = quatNormalize(b);
  let cosTheta = qa[0] * qb[0] + qa[1] * qb[1] + qa[2] * qb[2] + qa[3] * qb[3];

  if (cosTheta < 0) {
    qb = [-qb[0], -qb[1], -qb[2], -qb[3]];
    cosTheta = -cosTheta;
  }

  if (cosTheta > 0.9995) {
    return quatNormalize([
      qa[0] + (qb[0] - qa[0]) * t,
      qa[1] + (qb[1] - qa[1]) * t,
      qa[2] + (qb[2] - qa[2]) * t,
      qa[3] + (qb[3] - qa[3]) * t
    ]);
  }

  const theta = Math.acos(clamp(cosTheta, -1, 1));
  const sinTheta = Math.sin(theta);
  const wa = Math.sin((1 - t) * theta) / sinTheta;
  const wb = Math.sin(t * theta) / sinTheta;
  return quatNormalize([
    qa[0] * wa + qb[0] * wb,
    qa[1] * wa + qb[1] * wb,
    qa[2] * wa + qb[2] * wb,
    qa[3] * wa + qb[3] * wb
  ]);
}
