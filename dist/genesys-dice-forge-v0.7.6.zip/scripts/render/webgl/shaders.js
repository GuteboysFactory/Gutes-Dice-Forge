export const DIE_VERTEX_SHADER = `
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute float aFaceIndex;
attribute vec2 aFaceUv;
uniform mat4 uModel;
uniform mat4 uViewProjection;
varying vec3 vNormal;
varying vec3 vWorldPosition;
varying vec3 vLocalPosition;
varying float vFaceIndex;
varying vec2 vFaceUv;

void main() {
  vec4 world = uModel * vec4(aPosition, 1.0);
  vWorldPosition = world.xyz;
  vLocalPosition = aPosition;
  vNormal = normalize(mat3(uModel) * aNormal);
  vFaceIndex = aFaceIndex;
  vFaceUv = aFaceUv;
  gl_Position = uViewProjection * world;
}
`;

export const DIE_FRAGMENT_SHADER = `
precision mediump float;
uniform vec3 uBaseColor;
uniform vec3 uEdgeTint;
uniform vec3 uCameraPosition;
uniform vec3 uLightDirection;
uniform float uTargetFaceIndex;
uniform float uOpacity;
uniform float uRoughness;
uniform float uMetallic;
uniform float uGrain;
uniform sampler2D uArtworkTexture;
uniform vec2 uArtworkGrid;
uniform float uArtworkStrength;
varying vec3 vNormal;
varying vec3 vWorldPosition;
varying vec3 vLocalPosition;
varying float vFaceIndex;
varying vec2 vFaceUv;

float hash31(vec3 p) {
  p = fract(p * 0.1031);
  p += dot(p, p.yzx + 33.33);
  return fract((p.x + p.y) * p.z);
}

void main() {
  vec3 normal = normalize(vNormal);
  vec3 lightDir = normalize(-uLightDirection);
  float ndotl = max(dot(normal, lightDir), 0.0);
  vec3 viewDir = normalize(uCameraPosition - vWorldPosition);
  vec3 halfDir = normalize(lightDir + viewDir);
  float ndoth = max(dot(normal, halfDir), 0.0);
  float ndotv = max(dot(normal, viewDir), 0.0);

  // Polished enamel/stone body with a separate clear-coat highlight. The trim
  // is painted into the face atlas, while this shader gives the whole object
  // the physical tabletop-dice response seen in the premium target render.
  float specPower = mix(82.0, 20.0, clamp(uRoughness, 0.0, 1.0));
  float specular = pow(ndoth, specPower) * mix(0.30, 0.64, uMetallic);
  float clearcoat = pow(ndoth, 115.0) * (1.0 - clamp(uRoughness, 0.0, 1.0)) * 0.34;
  float fresnel = pow(1.0 - ndotv, 3.2) * 0.16;
  float selected = 1.0 - step(0.35, abs(vFaceIndex - uTargetFaceIndex));

  float grainNoise = (hash31(vLocalPosition * 31.0 + vec3(vFaceIndex * 0.73)) - 0.5) * uGrain;
  float subtleBodyVariation = sin((vLocalPosition.x * 11.0 + vLocalPosition.z * 7.0 + vFaceIndex) * 2.0) * 0.006;
  vec3 faceColor = mix(uBaseColor, uEdgeTint, selected * 0.022);
  faceColor *= 1.0 + grainNoise + subtleBodyVariation;
  vec3 lit = faceColor * (0.43 + ndotl * 0.72) + vec3(specular + clearcoat + fresnel);

  float fi = floor(vFaceIndex + 0.5);
  float col = mod(fi, max(1.0, uArtworkGrid.x));
  float row = floor(fi / max(1.0, uArtworkGrid.x));
  float atlasRow = max(0.0, uArtworkGrid.y - 1.0 - row);
  vec2 atlasUv = (vec2(col, atlasRow) + clamp(vFaceUv, 0.002, 0.998)) / max(vec2(1.0), uArtworkGrid);
  vec4 artwork = texture2D(uArtworkTexture, atlasUv);
  float artAlpha = artwork.a * clamp(uArtworkStrength, 0.0, 1.25);
  vec3 artLit = artwork.rgb * (0.58 + ndotl * 0.57)
    + vec3(specular * 0.22 + clearcoat * 0.34 + fresnel * 0.12);
  lit = mix(lit, artLit, clamp(artAlpha, 0.0, 1.0));

  gl_FragColor = vec4(lit, uOpacity);
}
`;

export const EDGE_VERTEX_SHADER = `
attribute vec3 aPosition;
uniform mat4 uModel;
uniform mat4 uViewProjection;
uniform float uInflate;
void main() {
  gl_Position = uViewProjection * uModel * vec4(aPosition * uInflate, 1.0);
}
`;

export const EDGE_FRAGMENT_SHADER = `
precision mediump float;
uniform vec3 uColor;
uniform float uOpacity;
void main() {
  gl_FragColor = vec4(uColor, uOpacity);
}
`;

export const SYMBOL_VERTEX_SHADER = `
attribute vec3 aPosition;
uniform mat4 uModel;
uniform mat4 uViewProjection;
void main() {
  gl_Position = uViewProjection * uModel * vec4(aPosition, 1.0);
}
`;

export const SYMBOL_FRAGMENT_SHADER = `
precision mediump float;
uniform vec3 uColor;
uniform float uOpacity;
uniform float uGlow;
void main() {
  vec3 color = uColor * (1.0 + uGlow * 0.9);
  gl_FragColor = vec4(color, uOpacity);
}
`;

export const SHADOW_VERTEX_SHADER = `
attribute vec3 aPosition;
attribute vec2 aUv;
uniform mat4 uModel;
uniform mat4 uViewProjection;
varying vec2 vUv;
void main() {
  vUv = aUv;
  gl_Position = uViewProjection * uModel * vec4(aPosition, 1.0);
}
`;

export const SHADOW_FRAGMENT_SHADER = `
precision mediump float;
varying vec2 vUv;
uniform float uOpacity;
void main() {
  vec2 p = vUv * 2.0 - 1.0;
  float radius = dot(p, p);
  float alpha = (1.0 - smoothstep(0.05, 1.0, radius)) * uOpacity;
  gl_FragColor = vec4(0.0, 0.0, 0.0, alpha);
}
`;
