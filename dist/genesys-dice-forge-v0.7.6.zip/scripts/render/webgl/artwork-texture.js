import { getDieDefinition } from "../../core/dice-types.js";

// High-resolution face atlas. The dice are deliberately compact on screen, so
// glyph silhouettes need plenty of source resolution before perspective
// projection and antialiasing.
const TILE_SIZE = 512;
const SYMBOL_NAMES = ["success", "failure", "advantage", "threat", "triumph", "despair"];
const SYMBOL_CACHE = new Map();
const TINT_CACHE = new Map();

function hash32(value) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < value.length; i += 1) {
    h ^= value.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function rngFor(seedText) {
  let state = hash32(seedText) || 1;
  return () => {
    state += 0x6D2B79F5;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function regularPolygon(ctx, cx, cy, radius, sides, rotation = -Math.PI / 2) {
  ctx.beginPath();
  for (let i = 0; i < sides; i += 1) {
    const angle = rotation + i * Math.PI * 2 / sides;
    const x = cx + Math.cos(angle) * radius;
    const y = cy + Math.sin(angle) * radius;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

function maskUrl(name) {
  return new URL(`../../../assets/symbols/${name}-mask.png`, import.meta.url).href;
}

function loadImage(url) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.decoding = "async";
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error(`[Genesys Dice Forge] Failed to load artwork asset: ${url}`));
    image.src = url;
  });
}

async function getSymbolMasks() {
  await Promise.all(SYMBOL_NAMES.map(async (name) => {
    if (SYMBOL_CACHE.has(name)) return;
    SYMBOL_CACHE.set(name, await loadImage(maskUrl(name)));
  }));
  return SYMBOL_CACHE;
}

function tintedMask(name, image, color) {
  const key = `${name}:${color}`;
  if (TINT_CACHE.has(key)) return TINT_CACHE.get(key);
  const canvas = document.createElement("canvas");
  canvas.width = image.naturalWidth || image.width || 512;
  canvas.height = image.naturalHeight || image.height || 512;
  const ctx = canvas.getContext("2d", { alpha: true });
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
  ctx.globalCompositeOperation = "source-in";
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.globalCompositeOperation = "source-over";
  TINT_CACHE.set(key, canvas);
  return canvas;
}

function layoutFor(symbols, shape) {
  if (symbols.length <= 1) return [[0, 0, 1.0]];

  // The physical Genesys dice use two discrete glyphs on double/mixed result
  // faces. Do not collapse them into x2 text or a decorative combined badge.
  if (shape === "d8") {
    // Triangular faces read best with a compact vertical/diagonal composition.
    if (symbols[0] === symbols[1]) {
      return [[-0.07, -0.19, 0.64], [0.07, 0.19, 0.64]];
    }
    return [[-0.15, -0.08, 0.64], [0.15, 0.10, 0.64]];
  }

  if (symbols[0] === symbols[1]) {
    return [[-0.18, -0.11, 0.70], [0.18, 0.11, 0.70]];
  }
  return [[-0.20, 0.02, 0.70], [0.20, -0.02, 0.70]];
}

function drawSurfaceWear(ctx, x, y, size, type, faceIndex) {
  const random = rngFor(`${type}:${faceIndex}:premium-wear:v1`);
  ctx.save();
  ctx.beginPath();
  ctx.rect(x + 24, y + 24, size - 48, size - 48);
  ctx.clip();

  // Fine hairline scratches: enough to sell a physical object without making
  // the dice look dirty or reducing symbol readability.
  for (let i = 0; i < 18; i += 1) {
    const px = x + 52 + random() * (size - 104);
    const py = y + 52 + random() * (size - 104);
    const length = 12 + random() * 52;
    const angle = random() * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(px + Math.cos(angle) * length, py + Math.sin(angle) * length * 0.45);
    ctx.strokeStyle = random() > 0.5
      ? `rgba(255,255,255,${0.020 + random() * 0.035})`
      : `rgba(0,0,0,${0.025 + random() * 0.040})`;
    ctx.lineWidth = 0.8 + random() * 1.1;
    ctx.stroke();
  }

  // Tiny mottling under the clear coat.
  for (let i = 0; i < 42; i += 1) {
    const px = x + 38 + random() * (size - 76);
    const py = y + 38 + random() * (size - 76);
    const radius = 0.7 + random() * 2.2;
    ctx.fillStyle = i % 3 === 0
      ? `rgba(255,248,224,${0.018 + random() * 0.028})`
      : `rgba(0,0,0,${0.018 + random() * 0.030})`;
    ctx.beginPath();
    ctx.arc(px, py, radius, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawPremiumFacePanel(ctx, cx, cy, frameRadius, sides, rotation, metal) {
  ctx.save();
  ctx.lineJoin = "round";

  // Deep socket under the trim.
  regularPolygon(ctx, cx, cy, frameRadius, sides, rotation);
  ctx.strokeStyle = "rgba(9,8,7,0.78)";
  ctx.lineWidth = 22;
  ctx.shadowColor = "rgba(0,0,0,0.70)";
  ctx.shadowBlur = 13;
  ctx.stroke();

  // Main cast-metal trim. This intentionally replaces the older filigree-heavy
  // treatment: the premium target is a clean, physical die with forged edges.
  regularPolygon(ctx, cx, cy, frameRadius - 1, sides, rotation);
  const metalGradient = ctx.createLinearGradient(cx - frameRadius, cy - frameRadius, cx + frameRadius, cy + frameRadius);
  metalGradient.addColorStop(0.0, "rgba(255,244,208,0.72)");
  metalGradient.addColorStop(0.18, metal);
  metalGradient.addColorStop(0.52, "rgba(73,53,27,0.96)");
  metalGradient.addColorStop(0.82, metal);
  metalGradient.addColorStop(1.0, "rgba(255,235,182,0.62)");
  ctx.strokeStyle = metalGradient;
  ctx.lineWidth = 13;
  ctx.shadowColor = "rgba(255,225,160,0.20)";
  ctx.shadowBlur = 6;
  ctx.stroke();

  // Inner face bevel and a fine polished highlight.
  ctx.shadowBlur = 0;
  regularPolygon(ctx, cx, cy, frameRadius - 15, sides, rotation);
  ctx.strokeStyle = "rgba(255,255,255,0.25)";
  ctx.lineWidth = 3.2;
  ctx.stroke();
  regularPolygon(ctx, cx, cy, frameRadius - 22, sides, rotation);
  ctx.strokeStyle = "rgba(0,0,0,0.30)";
  ctx.lineWidth = 3.4;
  ctx.stroke();

  ctx.restore();
}

function drawEnamelGlaze(ctx, tileX, tileY, size, cx, cy, frameRadius, sides, rotation) {
  ctx.save();
  regularPolygon(ctx, cx, cy, frameRadius - 23, sides, rotation);
  ctx.clip();

  const clearcoat = ctx.createRadialGradient(
    cx - size * 0.15,
    cy - size * 0.19,
    size * 0.025,
    cx,
    cy,
    size * 0.54
  );
  clearcoat.addColorStop(0.0, "rgba(255,255,255,0.19)");
  clearcoat.addColorStop(0.24, "rgba(255,255,255,0.060)");
  clearcoat.addColorStop(0.64, "rgba(0,0,0,0.020)");
  clearcoat.addColorStop(1.0, "rgba(0,0,0,0.24)");
  ctx.fillStyle = clearcoat;
  ctx.fillRect(tileX, tileY, size, size);

  // Soft reflected strip as if from a large tabletop/studio light.
  const reflected = ctx.createLinearGradient(tileX, tileY, tileX + size, tileY + size);
  reflected.addColorStop(0.0, "rgba(255,255,255,0.00)");
  reflected.addColorStop(0.34, "rgba(255,255,255,0.055)");
  reflected.addColorStop(0.43, "rgba(255,255,255,0.00)");
  reflected.addColorStop(1.0, "rgba(255,255,255,0.00)");
  ctx.fillStyle = reflected;
  ctx.fillRect(tileX, tileY, size, size);
  ctx.restore();
}

function drawGlyph(ctx, name, mask, x, y, size, color, special = false) {
  if (!mask) return;
  const art = tintedMask(name, mask, color);

  // Recessed/printed physical glyph: a restrained low shadow plus one tiny
  // upper highlight. The master silhouette itself is never altered.
  ctx.save();
  ctx.shadowColor = special ? "rgba(255,220,125,0.26)" : "rgba(0,0,0,0.50)";
  ctx.shadowBlur = special ? 8 : 4;
  ctx.shadowOffsetY = 2;
  ctx.drawImage(art, x - size / 2, y - size / 2, size, size);
  ctx.restore();

  ctx.save();
  ctx.globalAlpha = special ? 0.17 : 0.08;
  ctx.globalCompositeOperation = "screen";
  ctx.drawImage(art, x - size / 2 - 0.8, y - size / 2 - 1.2, size, size);
  ctx.restore();
}

function drawFaceArtwork(ctx, type, definition, material, faceIndex, tileX, tileY, symbolMasks) {
  const size = TILE_SIZE;
  const cx = tileX + size / 2;
  const cy = tileY + size / 2;
  const sides = definition.shape === "d6" ? 4 : definition.shape === "d8" ? 3 : 5;
  const rotation = definition.shape === "d6" ? Math.PI / 4 : -Math.PI / 2;
  const frameRadius = definition.shape === "d8" ? 184 : definition.shape === "d12" ? 192 : 183;
  const metal = material.edge ?? "#b78a46";
  const glyphColor = material.symbol ?? "#111111";

  drawSurfaceWear(ctx, tileX, tileY, size, type, faceIndex);
  drawPremiumFacePanel(ctx, cx, cy, frameRadius, sides, rotation, metal);
  drawEnamelGlaze(ctx, tileX, tileY, size, cx, cy, frameRadius, sides, rotation);

  const symbols = definition.faces[faceIndex] ?? [];
  if (!symbols.length) return; // Real blank face stays truly blank.

  const placements = layoutFor(symbols, definition.shape);
  symbols.forEach((glyph, i) => {
    const [ox, oy, scale] = placements[i];
    const special = glyph === "triumph" || glyph === "despair";
    const baseSize = definition.shape === "d8"
      ? (symbols.length === 1 ? 236 : 205)
      : (symbols.length === 1 ? 238 : 208);
    drawGlyph(
      ctx,
      glyph,
      symbolMasks.get(glyph),
      cx + ox * 260,
      cy + oy * 260,
      baseSize * scale,
      glyphColor,
      special
    );
  });
}

export async function createDieArtworkTexture(gl, type, material) {
  const definition = getDieDefinition(type);
  if (!definition) return null;
  const symbolMasks = await getSymbolMasks();
  const cols = definition.sides <= 6 ? 3 : 4;
  const rows = Math.ceil(definition.sides / cols);
  const canvas = document.createElement("canvas");
  canvas.width = cols * TILE_SIZE;
  canvas.height = rows * TILE_SIZE;
  const ctx = canvas.getContext("2d", { alpha: true });
  if (!ctx) return null;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  definition.faces.forEach((_, faceIndex) => {
    const col = faceIndex % cols;
    const row = Math.floor(faceIndex / cols);
    drawFaceArtwork(
      ctx,
      type,
      definition,
      material,
      faceIndex,
      col * TILE_SIZE,
      row * TILE_SIZE,
      symbolMasks
    );
  });

  const texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, canvas);
  gl.bindTexture(gl.TEXTURE_2D, null);

  return { texture, cols, rows, tileSize: TILE_SIZE };
}
