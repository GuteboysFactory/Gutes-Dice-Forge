import { cross3, dot3, normalize3, sub3 } from "./math.js";

const PHI = (1 + Math.sqrt(5)) / 2;
const INV_PHI = 1 / PHI;

function uniqueKey(indices) {
  return [...indices].sort((a, b) => a - b).join(",");
}

function collectHullFaces(vertices, expectedVerticesPerFace) {
  const planeSets = new Map();
  const epsilon = 1e-5;

  for (let i = 0; i < vertices.length - 2; i += 1) {
    for (let j = i + 1; j < vertices.length - 1; j += 1) {
      for (let k = j + 1; k < vertices.length; k += 1) {
        const a = vertices[i];
        const b = vertices[j];
        const c = vertices[k];
        const rawNormal = cross3(sub3(b, a), sub3(c, a));
        const normalLength = Math.hypot(...rawNormal);
        if (normalLength < epsilon) continue;
        const normal = rawNormal.map((v) => v / normalLength);
        const offset = dot3(normal, a);

        let positive = false;
        let negative = false;
        const coplanar = [];
        for (let p = 0; p < vertices.length; p += 1) {
          const distance = dot3(normal, vertices[p]) - offset;
          if (Math.abs(distance) <= epsilon) coplanar.push(p);
          else if (distance > 0) positive = true;
          else negative = true;
          if (positive && negative) break;
        }

        if (positive && negative) continue;
        if (coplanar.length !== expectedVerticesPerFace) continue;
        planeSets.set(uniqueKey(coplanar), coplanar);
      }
    }
  }

  const faces = [...planeSets.values()].map((indices) => orderFace(vertices, indices));
  faces.sort((a, b) => {
    const ac = faceCenter(vertices, a);
    const bc = faceCenter(vertices, b);
    const ay = Math.atan2(ac[2], ac[0]);
    const by = Math.atan2(bc[2], bc[0]);
    if (Math.abs(ac[1] - bc[1]) > 1e-5) return bc[1] - ac[1];
    return ay - by;
  });
  return faces;
}

function faceCenter(vertices, face) {
  const center = [0, 0, 0];
  for (const index of face) {
    center[0] += vertices[index][0];
    center[1] += vertices[index][1];
    center[2] += vertices[index][2];
  }
  return center.map((v) => v / face.length);
}

function orderFace(vertices, indices) {
  const center = faceCenter(vertices, indices);
  let normal = normalize3(cross3(
    sub3(vertices[indices[1]], vertices[indices[0]]),
    sub3(vertices[indices[2]], vertices[indices[0]])
  ));
  if (dot3(normal, center) < 0) normal = normal.map((v) => -v);

  const reference = Math.abs(normal[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
  const tangent = normalize3(cross3(reference, normal));
  const bitangent = cross3(normal, tangent);

  const ordered = [...indices].sort((ia, ib) => {
    const va = sub3(vertices[ia], center);
    const vb = sub3(vertices[ib], center);
    const aa = Math.atan2(dot3(va, bitangent), dot3(va, tangent));
    const ab = Math.atan2(dot3(vb, bitangent), dot3(vb, tangent));
    return aa - ab;
  });

  const n = normalize3(cross3(
    sub3(vertices[ordered[1]], vertices[ordered[0]]),
    sub3(vertices[ordered[2]], vertices[ordered[0]])
  ));
  if (dot3(n, center) < 0) ordered.reverse();
  return ordered;
}

function buildBuffers(vertices, faces) {
  const positions = [];
  const normals = [];
  const faceIndices = [];
  const faceUvs = [];
  const edgePositions = [];
  const uniqueEdges = new Set();
  const faceNormals = [];
  const faceCenters = [];
  const faceTangents = [];
  const faceBitangents = [];

  faces.forEach((face, faceIndex) => {
    const center = faceCenter(vertices, face);
    let normal = normalize3(cross3(
      sub3(vertices[face[1]], vertices[face[0]]),
      sub3(vertices[face[2]], vertices[face[0]])
    ));
    if (dot3(normal, center) < 0) normal = normal.map((v) => -v);
    faceNormals.push(normal);
    faceCenters.push(center);
    const reference = Math.abs(normal[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
    const tangent = normalize3(cross3(reference, normal));
    const bitangent = normalize3(cross3(normal, tangent));
    faceTangents.push(tangent);
    faceBitangents.push(bitangent);

    const projected = face.map((vertexIndex) => {
      const relative = sub3(vertices[vertexIndex], center);
      return [dot3(relative, tangent), dot3(relative, bitangent)];
    });
    const uvRadius = Math.max(1e-6, ...projected.map(([x, y]) => Math.hypot(x, y))) * 1.08;
    const localUv = new Map();
    face.forEach((vertexIndex, localIndex) => {
      const [x, y] = projected[localIndex];
      localUv.set(vertexIndex, [0.5 + x / (2 * uvRadius), 0.5 + y / (2 * uvRadius)]);
    });

    for (let i = 1; i < face.length - 1; i += 1) {
      for (const vertexIndex of [face[0], face[i], face[i + 1]]) {
        positions.push(...vertices[vertexIndex]);
        normals.push(...normal);
        faceIndices.push(faceIndex);
        faceUvs.push(...localUv.get(vertexIndex));
      }
    }

    for (let i = 0; i < face.length; i += 1) {
      const a = face[i];
      const b = face[(i + 1) % face.length];
      const key = a < b ? `${a}:${b}` : `${b}:${a}`;
      if (uniqueEdges.has(key)) continue;
      uniqueEdges.add(key);
      edgePositions.push(...vertices[a], ...vertices[b]);
    }
  });

  const radius = Math.max(...vertices.map((v) => Math.hypot(...v)));
  const normalizedVertices = vertices.map((v) => v.map((n) => n / radius));
  const normalization = 1 / radius;

  return {
    positions: new Float32Array(positions.map((v) => v * normalization)),
    normals: new Float32Array(normals),
    faceIndices: new Float32Array(faceIndices),
    faceUvs: new Float32Array(faceUvs),
    edgePositions: new Float32Array(edgePositions.map((v) => v * normalization)),
    vertices: normalizedVertices,
    faces,
    faceNormals,
    faceCenters: faceCenters.map((c) => c.map((v) => v * normalization)),
    faceTangents,
    faceBitangents,
    faceCount: faces.length
  };
}

function cubeVertices() {
  return [
    [-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
    [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]
  ];
}

function octahedronVertices() {
  return [
    [1, 0, 0], [-1, 0, 0], [0, 1, 0],
    [0, -1, 0], [0, 0, 1], [0, 0, -1]
  ];
}

function dodecahedronVertices() {
  const vertices = [];
  for (const x of [-1, 1]) {
    for (const y of [-1, 1]) {
      for (const z of [-1, 1]) vertices.push([x, y, z]);
    }
  }
  for (const y of [-INV_PHI, INV_PHI]) {
    for (const z of [-PHI, PHI]) vertices.push([0, y, z]);
  }
  for (const x of [-INV_PHI, INV_PHI]) {
    for (const y of [-PHI, PHI]) vertices.push([x, y, 0]);
  }
  for (const x of [-PHI, PHI]) {
    for (const z of [-INV_PHI, INV_PHI]) vertices.push([x, 0, z]);
  }
  return vertices;
}

function createShape(vertices, expectedVerticesPerFace, expectedFaceCount) {
  const faces = collectHullFaces(vertices, expectedVerticesPerFace);
  if (faces.length !== expectedFaceCount) {
    throw new Error(`[Genesys Dice Forge] Geometry generation expected ${expectedFaceCount} faces but found ${faces.length}.`);
  }
  return buildBuffers(vertices, faces);
}

export const SHAPE_GEOMETRY = Object.freeze({
  d6: createShape(cubeVertices(), 4, 6),
  d8: createShape(octahedronVertices(), 3, 8),
  d12: createShape(dodecahedronVertices(), 5, 12)
});

export function getShapeGeometry(shape) {
  return SHAPE_GEOMETRY[shape] ?? null;
}
