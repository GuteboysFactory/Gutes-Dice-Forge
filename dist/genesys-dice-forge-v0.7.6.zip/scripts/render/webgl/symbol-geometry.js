import { getDieDefinition } from "../../core/dice-types.js";
import { getShapeGeometry } from "./geometry.js";
import { add3, scale3 } from "./math.js";

function line(a, b) { return [a, b]; }

function circleSegments(radius = 0.28, segments = 28) {
  const out = [];
  for (let i = 0; i < segments; i += 1) {
    const a = (i / segments) * Math.PI * 2;
    const b = ((i + 1) / segments) * Math.PI * 2;
    out.push(line([Math.cos(a) * radius, Math.sin(a) * radius], [Math.cos(b) * radius, Math.sin(b) * radius]));
  }
  return out;
}

function fourPointStarSegments(outer = 0.34, inner = 0.12) {
  const vertices = [];
  for (let i = 0; i < 8; i += 1) {
    const angle = -Math.PI / 2 + i * Math.PI / 4;
    const r = i % 2 ? inner : outer;
    vertices.push([Math.cos(angle) * r, Math.sin(angle) * r]);
  }
  return vertices.map((v, i) => line(v, vertices[(i + 1) % vertices.length]));
}

function triumphSegments() {
  const out = [...circleSegments(0.34, 32), ...circleSegments(0.12, 24)];
  // Eight inward sun-spokes matching the user-approved ring/sun silhouette.
  for (let i = 0; i < 8; i += 1) {
    const a = -Math.PI / 2 + i * Math.PI / 4;
    const spread = 0.095;
    const p1 = [Math.cos(a - spread) * 0.29, Math.sin(a - spread) * 0.29];
    const p2 = [Math.cos(a) * 0.16, Math.sin(a) * 0.16];
    const p3 = [Math.cos(a + spread) * 0.29, Math.sin(a + spread) * 0.29];
    out.push(line(p1, p2), line(p2, p3));
  }
  return out;
}

const GLYPHS = Object.freeze({
  // Regular faces are texture artwork in v0.4.0. These outlines remain only as
  // a compatibility fallback if the function is ever called without specialOnly.
  success: [...circleSegments(0.12, 20)],
  failure: fourPointStarSegments(0.34, 0.08),
  advantage: [
    line([0, -0.34], [0.30, 0.28]), line([0.30, 0.28], [0, 0.08]),
    line([0, 0.08], [-0.30, 0.28]), line([-0.30, 0.28], [0, -0.34])
  ],
  threat: circleSegments(0.28, 24),
  triumph: triumphSegments(),
  despair: [...circleSegments(0.30, 28), ...fourPointStarSegments(0.35, 0.105)]
});

function placements(count) {
  if (count <= 1) return [[0, 0, 1]];
  if (count === 2) return [[-0.19, 0, 0.72], [0.19, 0, 0.72]];
  return [[0, 0.18, 0.64], [-0.18, -0.13, 0.64], [0.18, -0.13, 0.64]];
}

function projectPoint(center, tangent, bitangent, normal, x, y, lift = 0.020) {
  let p = center;
  p = add3(p, scale3(tangent, x));
  p = add3(p, scale3(bitangent, y));
  p = add3(p, scale3(normal, lift));
  return p;
}

export function buildDieSymbolLines(type, { specialOnly = false } = {}) {
  const definition = getDieDefinition(type);
  if (!definition) return new Float32Array();
  const geometry = getShapeGeometry(definition.shape);
  const positions = [];

  definition.faces.forEach((symbols, faceIndex) => {
    if (!symbols?.length) return;
    if (specialOnly && !symbols.some((symbol) => symbol === "triumph" || symbol === "despair")) return;
    const center = geometry.faceCenters[faceIndex];
    const tangent = geometry.faceTangents[faceIndex];
    const bitangent = geometry.faceBitangents[faceIndex];
    const normal = geometry.faceNormals[faceIndex];
    const slots = placements(symbols.length);

    symbols.forEach((symbol, symbolIndex) => {
      const glyph = GLYPHS[symbol] ?? [];
      const [ox, oy, size] = slots[symbolIndex] ?? slots[0];
      for (const [a, b] of glyph) {
        const pa = projectPoint(center, tangent, bitangent, normal, ox + a[0] * size, oy + a[1] * size);
        const pb = projectPoint(center, tangent, bitangent, normal, ox + b[0] * size, oy + b[1] * size);
        positions.push(...pa, ...pb);
      }
    });
  });

  return new Float32Array(positions);
}
