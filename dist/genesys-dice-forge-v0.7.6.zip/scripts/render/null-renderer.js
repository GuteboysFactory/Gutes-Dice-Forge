export class NullRenderer {
  constructor({ debug = false, reason = "renderer-not-implemented" } = {}) {
    this.debug = debug;
    this.reason = reason;
  }

  async initialize() {
    if (this.debug) console.log(`[Genesys Dice Forge] NullRenderer initialized (${this.reason}).`);
  }

  get capabilities() {
    return { renderer3d: false, renderer: "null", reason: this.reason };
  }

  async animate(payload) {
    if (this.debug) console.log("[Genesys Dice Forge] Roll accepted by fallback renderer:", payload);
    return { rendered: false, reason: this.reason, payload };
  }

  async preview() {
    ui?.notifications?.warn?.(`Genesys Dice Forge: 3D renderer unavailable (${this.reason}).`);
    return { rendered: false, reason: this.reason };
  }

  destroy() {}
}
