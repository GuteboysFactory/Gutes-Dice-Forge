import { getDieDefinition, SYMBOLS } from "./dice-types.js";

function assert(condition, message) {
  if (!condition) throw new Error(`[Genesys Dice Forge] ${message}`);
}

export function validateRollPayload(payload) {
  assert(payload && typeof payload === "object", "Roll payload must be an object.");
  assert(Array.isArray(payload.dice), "Roll payload must contain a dice array.");

  for (const [index, die] of payload.dice.entries()) {
    const definition = getDieDefinition(die?.type);
    assert(definition, `Unknown die type at dice[${index}]: ${die?.type}`);
    assert(Number.isInteger(die.faceIndex), `dice[${index}].faceIndex must be an integer.`);
    assert(die.faceIndex >= 0 && die.faceIndex < definition.sides,
      `dice[${index}].faceIndex ${die.faceIndex} is outside ${definition.shape}.`);

    if (die.rawSymbols !== undefined) {
      assert(die.rawSymbols && typeof die.rawSymbols === "object",
        `dice[${index}].rawSymbols must be an object when supplied.`);
      for (const key of Object.keys(die.rawSymbols)) {
        assert(SYMBOLS.includes(key), `Unsupported symbol '${key}' in dice[${index}].rawSymbols.`);
      }
    }
  }

  return payload;
}
