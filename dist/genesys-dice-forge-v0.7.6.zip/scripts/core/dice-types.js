export const DICE_TYPES = Object.freeze({
  boost: Object.freeze({
    id: "boost", code: "B", sides: 6, polarity: "positive", shape: "d6",
    faces: Object.freeze([
      [], [], ["success"], ["success", "advantage"], ["advantage", "advantage"], ["advantage"]
    ])
  }),
  setback: Object.freeze({
    id: "setback", code: "S", sides: 6, polarity: "negative", shape: "d6",
    faces: Object.freeze([
      [], [], ["failure"], ["failure"], ["threat"], ["threat"]
    ])
  }),
  ability: Object.freeze({
    id: "ability", code: "A", sides: 8, polarity: "positive", shape: "d8",
    faces: Object.freeze([
      [], ["success"], ["success"], ["success", "success"], ["advantage"], ["advantage"],
      ["success", "advantage"], ["advantage", "advantage"]
    ])
  }),
  difficulty: Object.freeze({
    id: "difficulty", code: "D", sides: 8, polarity: "negative", shape: "d8",
    faces: Object.freeze([
      [], ["failure"], ["failure", "failure"], ["threat"], ["threat"], ["threat"],
      ["threat", "threat"], ["failure", "threat"]
    ])
  }),
  proficiency: Object.freeze({
    id: "proficiency", code: "P", sides: 12, polarity: "positive", shape: "d12",
    faces: Object.freeze([
      [], ["success"], ["success"], ["success", "success"], ["success", "success"], ["advantage"],
      ["success", "advantage"], ["success", "advantage"], ["success", "advantage"],
      ["advantage", "advantage"], ["advantage", "advantage"], ["triumph"]
    ])
  }),
  challenge: Object.freeze({
    id: "challenge", code: "C", sides: 12, polarity: "negative", shape: "d12",
    faces: Object.freeze([
      [], ["failure"], ["failure"], ["failure", "failure"], ["failure", "failure"], ["threat"],
      ["threat"], ["failure", "threat"], ["failure", "threat"], ["threat", "threat"],
      ["threat", "threat"], ["despair"]
    ])
  })
});

export const SYMBOLS = Object.freeze([
  "success",
  "failure",
  "advantage",
  "threat",
  "triumph",
  "despair"
]);

export function getDieDefinition(type) {
  return DICE_TYPES[type] ?? null;
}

export function getFaceSymbols(type, faceIndex) {
  const definition = getDieDefinition(type);
  return definition?.faces?.[faceIndex] ?? [];
}
