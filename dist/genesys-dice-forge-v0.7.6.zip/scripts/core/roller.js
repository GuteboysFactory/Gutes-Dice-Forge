import { DICE_TYPES, getDieDefinition, getFaceSymbols } from "./dice-types.js";

const TYPE_ORDER = Object.freeze([
  "boost", "setback", "ability", "difficulty", "proficiency", "challenge"
]);

function assertPool(pool) {
  if (!pool || typeof pool !== "object") throw new Error("[Genesys Dice Forge] Dice pool must be an object.");
  for (const type of TYPE_ORDER) {
    const value = Number(pool[type] ?? 0);
    if (!Number.isInteger(value) || value < 0 || value > 30) {
      throw new Error(`[Genesys Dice Forge] Pool count for '${type}' must be an integer from 0 to 30.`);
    }
  }
}

function randomFloat() {
  const cryptoApi = globalThis.crypto;
  if (cryptoApi?.getRandomValues) {
    const data = new Uint32Array(1);
    cryptoApi.getRandomValues(data);
    return data[0] / 4294967296;
  }
  return Math.random();
}

function randomFace(sides) {
  return Math.floor(randomFloat() * sides);
}

export function normalizePool(pool = {}) {
  assertPool(pool);
  return Object.fromEntries(TYPE_ORDER.map((type) => [type, Number(pool[type] ?? 0)]));
}

export function poolDiceCount(pool = {}) {
  const normalized = normalizePool(pool);
  return TYPE_ORDER.reduce((sum, type) => sum + normalized[type], 0);
}

export function resolveDice(dice) {
  const raw = {
    success: 0,
    failure: 0,
    advantage: 0,
    threat: 0,
    triumph: 0,
    despair: 0
  };

  for (const die of dice) {
    for (const symbol of getFaceSymbols(die.type, die.faceIndex)) {
      raw[symbol] = (raw[symbol] ?? 0) + 1;
    }
  }

  // Triumph and Despair remain uncancelled specials while also contributing
  // their associated Success/Failure exactly once to the narrative result.
  const successTotal = raw.success + raw.triumph;
  const failureTotal = raw.failure + raw.despair;
  const netSuccess = successTotal - failureTotal;
  const netAdvantage = raw.advantage - raw.threat;

  return {
    raw,
    totals: {
      success: successTotal,
      failure: failureTotal,
      advantage: raw.advantage,
      threat: raw.threat,
      triumph: raw.triumph,
      despair: raw.despair
    },
    net: {
      netSuccess,
      netAdvantage,
      succeeded: netSuccess > 0,
      triumph: raw.triumph,
      despair: raw.despair
    }
  };
}

export function createSimulatedRollPayload(pool, context = {}) {
  const normalized = normalizePool(pool);
  const dice = [];

  for (const type of TYPE_ORDER) {
    const definition = getDieDefinition(type);
    for (let index = 0; index < normalized[type]; index += 1) {
      const faceIndex = randomFace(definition.sides);
      dice.push({ type, faceIndex });
    }
  }

  const resolved = resolveDice(dice);
  return {
    rollId: `sim-${Date.now()}-${Math.floor(randomFloat() * 1e9)}`,
    dice,
    totals: resolved.totals,
    net: resolved.net,
    rawSymbols: resolved.raw,
    context: { ...context, simulator: true }
  };
}

export { TYPE_ORDER, DICE_TYPES };
