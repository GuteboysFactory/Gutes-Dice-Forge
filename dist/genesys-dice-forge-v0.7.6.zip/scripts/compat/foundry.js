export const MODULE_ID = "genesys-dice-forge";
export const FOUNDRY_TARGETS = Object.freeze({
  minimum: "13.351",
  generations: Object.freeze([13, 14])
});

export function foundryGeneration() {
  return Number(game?.release?.generation ?? 0);
}

export function foundryBuild() {
  return Number(game?.release?.build ?? 0);
}

export function assertSupportedFoundry() {
  const generation = foundryGeneration();
  const build = foundryBuild();
  if (!FOUNDRY_TARGETS.generations.includes(generation)) {
    console.warn(`[Genesys Dice Forge] Foundry generation ${generation} is outside the supported target matrix (13/14).`);
    return false;
  }
  if (generation === 13 && build && build < 351) {
    console.warn(`[Genesys Dice Forge] Foundry V13 build ${build} is below the supported minimum 13.351.`);
    return false;
  }
  return true;
}

export function getViewportHost() {
  // Deliberately separate from Foundry's PIXI/Canvas groups. The module uses
  // an independent transparent WebGL canvas over the application viewport.
  return document.body;
}

export function getModuleAssetUrl(relativePath) {
  const path = `modules/${MODULE_ID}/${String(relativePath).replace(/^\/+/, "")}`;
  const routeHelper = globalThis.foundry?.utils?.getRoute;
  return typeof routeHelper === "function" ? routeHelper(path) : `/${path}`;
}
