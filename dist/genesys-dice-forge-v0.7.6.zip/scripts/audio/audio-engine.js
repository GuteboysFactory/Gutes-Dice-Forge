import { getModuleAssetUrl } from "../compat/foundry.js";

const BANK = Object.freeze({
  light: ["light-01.ogg", "light-02.ogg", "light-03.ogg"],
  medium: ["medium-01.ogg", "medium-02.ogg"],
  heavy: ["heavy-01.ogg", "heavy-02.ogg"]
});

function pick(list) {
  return list[Math.floor(Math.random() * list.length)];
}

function clamp(value, min = 0, max = 1) {
  return Math.max(min, Math.min(max, value));
}

export class DiceAudioEngine {
  constructor({ moduleId, debug = false } = {}) {
    this.moduleId = moduleId;
    this.debug = debug;
    this.active = new Set();
    this.destroyed = false;
  }

  get capabilities() {
    return Object.freeze({
      layeredRollAudio: true,
      adaptiveDiceCountMix: true,
      randomizedSamplePlayback: true,
      source: "user-supplied-sample-pack"
    });
  }

  stopAll() {
    for (const audio of this.active) {
      try {
        audio.pause();
        audio.currentTime = 0;
      } catch (_) {}
    }
    this.active.clear();
  }

  #asset(file) {
    return getModuleAssetUrl(`assets/audio/dice/${file}`);
  }

  #play(file, { delay = 0, volume = 1, rate = 1 } = {}) {
    if (this.destroyed) return;
    const launch = () => {
      if (this.destroyed) return;
      const audio = new Audio(this.#asset(file));
      audio.preload = "auto";
      audio.volume = clamp(volume);
      audio.playbackRate = clamp(rate, 0.90, 1.10);
      audio.preservesPitch = false;
      this.active.add(audio);
      const cleanup = () => this.active.delete(audio);
      audio.addEventListener("ended", cleanup, { once: true });
      audio.addEventListener("error", cleanup, { once: true });
      const promise = audio.play();
      if (promise?.catch) {
        promise.catch((error) => {
          cleanup();
          if (this.debug) console.debug("[Genesys Dice Forge] Dice audio playback was blocked or failed.", error);
        });
      }
    };
    if (delay > 0) window.setTimeout(launch, delay);
    else launch();
  }

  playRoll(payload, { volume = 0.72 } = {}) {
    if (this.destroyed) return;
    const count = Math.max(1, Number(payload?.dice?.length ?? 1));
    this.stopAll();

    const master = clamp(volume);
    const jitter = () => 0.965 + Math.random() * 0.07;

    if (count <= 2) {
      this.#play(pick(BANK.light), { volume: master * 0.86, rate: jitter() });
      if (count === 2) {
        this.#play(pick(BANK.light), { delay: 45 + Math.random() * 45, volume: master * 0.48, rate: jitter() });
      }
      return;
    }

    if (count <= 5) {
      this.#play(pick(BANK.medium), { volume: master * 0.86, rate: jitter() });
      this.#play(pick(BANK.light), { delay: 35 + Math.random() * 60, volume: master * 0.44, rate: jitter() });
      return;
    }

    if (count <= 9) {
      this.#play(pick(BANK.heavy), { volume: master * 0.82, rate: jitter() });
      this.#play(pick(BANK.medium), { delay: 35 + Math.random() * 55, volume: master * 0.42, rate: jitter() });
      this.#play(pick(BANK.light), { delay: 85 + Math.random() * 65, volume: master * 0.25, rate: jitter() });
      return;
    }

    this.#play(pick(BANK.heavy), { volume: master * 0.78, rate: jitter() });
    this.#play(pick(BANK.heavy), { delay: 70 + Math.random() * 55, volume: master * 0.46, rate: jitter() });
    this.#play(pick(BANK.medium), { delay: 125 + Math.random() * 65, volume: master * 0.30, rate: jitter() });
    this.#play(pick(BANK.light), { delay: 180 + Math.random() * 70, volume: master * 0.18, rate: jitter() });
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.stopAll();
  }
}
